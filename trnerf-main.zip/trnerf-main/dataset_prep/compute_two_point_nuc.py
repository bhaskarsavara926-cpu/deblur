import argparse
import numpy as np
from pathlib import Path
import h5py

from trnerf_utils import open_h5_image_file

if __name__ == "__main__":
    # Process arguments
    parser = argparse.ArgumentParser(description='Compute pixelwise gains and offsets with two point NUC.')
    parser.add_argument('--path-images', type=Path, help="Path to H5 file with images to process.")
    parser.add_argument('--t-start-hot', type=float, help='Time at the start of the hot source.')
    parser.add_argument('--t-stop-hot', type=float, help='Time at the end of the hot source.')
    parser.add_argument('--t-start-cold', type=float, help='Time at the start of the cold source.')
    parser.add_argument('--t-stop-cold', type=float, help='Time at the end of the cold source.')
    parser.add_argument('--path-output', type=Path, help='Path to the output H5 file.')

    args = parser.parse_args()

    # Open the H5 image file
    image_data_dict = open_h5_image_file(args.path_images)

    # Read in images with the hot and cold sources
    timestamps = image_data_dict['timestamps']
    images_hot = image_data_dict['images'][(timestamps > args.t_start_hot) * (timestamps < args.t_stop_hot)]
    images_cold = image_data_dict['images'][(timestamps > args.t_start_cold) * (timestamps < args.t_stop_cold)]

    # Compute two point NUC
    val_avg_hot = np.mean(images_hot)
    val_avg_cold = np.mean(images_cold)
    img_avg_hot = np.mean(images_hot, axis=0)
    img_avg_cold = np.mean(images_cold, axis=0)

    gain = (img_avg_hot - img_avg_cold) / (val_avg_hot - val_avg_cold)
    offset = img_avg_cold - gain * val_avg_cold

    # Write out the results
    h5_file = h5py.File(args.path_output, 'w')
    h5_file.create_dataset(name='gain', data=gain)
    h5_file.create_dataset(name='offset', data=offset)
