import numpy as np
from scipy.spatial.transform import Rotation
import argparse
import pickle
from pathlib import Path
import h5py

from trnerf_utils import create_output_directory, read_yaml, get_transformation_from_calib, invert_transformation_matrix

# Requires a file from COLMAP: https://github.com/colmap/colmap/blob/main/scripts/python/read_write_model.py
from read_write_model import read_images_binary

def to_transformation(qvec, tvec):
    qvec_xyzw = np.array([
        qvec[1],
        qvec[2],
        qvec[3],
        qvec[0]])
    rot = Rotation.from_quat(qvec_xyzw).as_matrix()
    transformation_w_to_c = np.eye(4)
    transformation_w_to_c[:3, :3] = rot
    transformation_w_to_c[:3, 3] = tvec

    return transformation_w_to_c

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Combine COLMAP and HLOC poses, scale the poses, and output H5 pose files for each sequence.")
    parser.add_argument("--path-calibration-results", type=Path, help="Path to Kalibr camchain YAML file.")
    parser.add_argument("--path-colmap-model", type=Path, help="Path to COLMAP model.")
    parser.add_argument("--path-hloc-poses", type=Path, help="Path to HLOC poses pickle file.")
    parser.add_argument("--path-image-folders", type=Path, help="Path to folder containing image folders.")
    parser.add_argument("--path-output-folder", type=Path, help="Path to the output folder.")
    args = parser.parse_args()

    # Read in calibration results
    calibration_results = read_yaml(args.path_calibration_results)

    # Read in COLMAP poses
    images = read_images_binary(args.path_colmap_model / 'images.bin')
    transformations_world_to_mono_left = {}
    for key, image in images.items():
        transformations_world_to_mono_left[image.name] = to_transformation(image.qvec, image.tvec)

    # Read in HLOC poses
    poses_hloc = pickle.load(open(args.path_hloc_poses, 'rb'))
    transformations_world_to_mono_right = {}
    for name, pose in poses_hloc.items():
        if 'left' in name:
            transformations_world_to_mono_left[name] = to_transformation(pose[0], pose[1])
        else:
            transformations_world_to_mono_right[name] = to_transformation(pose[0], pose[1])

    # Compute the scale factor
    transformation_mono_left_to_mono_right = get_transformation_from_calib(calibration_results, 'mono_left',
        'mono_right')
    scale_factors = []
    for key_right in transformations_world_to_mono_right:
        key_left = key_right.replace('right', 'left')
        transformation_world_to_mono_left = transformations_world_to_mono_left[key_left]
        transformation_world_to_mono_right = transformations_world_to_mono_right[key_right]
        transformation_mono_left_to_mono_right_colmap = transformation_world_to_mono_right @ \
            invert_transformation_matrix(transformation_world_to_mono_left)
        scale_factors.append(np.linalg.norm(transformation_mono_left_to_mono_right[:3, 3]) /
            np.linalg.norm(transformation_mono_left_to_mono_right_colmap[:3, 3]))
    scale_factor = np.median(scale_factors)
    print(f'Computed scale factor: {scale_factor}')

    # Compute stats regarding colmap relative poses
    errors_translation = []
    errors_rotation = []
    for key_right in transformations_world_to_mono_right:
        key_left = key_right.replace('right', 'left')
        transformation_world_to_mono_left = transformations_world_to_mono_left[key_left]
        transformation_world_to_mono_right = transformations_world_to_mono_right[key_right]
        transformation_mono_left_to_mono_right_colmap = transformation_world_to_mono_right @ \
            invert_transformation_matrix(transformation_world_to_mono_left)
        errors_translation.append(np.linalg.norm(transformation_mono_left_to_mono_right[:3, 3] -
            transformation_mono_left_to_mono_right_colmap[:3, 3] * scale_factor))
        errors_rotation.append(np.linalg.norm(
            Rotation.from_matrix(
                transformation_mono_left_to_mono_right[:3, :3].T @
                    transformation_mono_left_to_mono_right_colmap[:3, :3]).as_rotvec(degrees=True)))
    print('COLMAP scaled left/right relative pose stats:\n'
          f'median/mean/max translation error: {np.median(errors_translation)} meters, {np.mean(errors_translation)} meters, {np.max(errors_translation)} meters\n'
          f'median/mean/max rotation error: {np.median(errors_rotation)} degrees, {np.mean(errors_rotation)} degrees, {np.max(errors_rotation)} degrees')

    # Get all sequence names
    names_sequence = []
    for key_left in transformations_world_to_mono_left:
        name_sequence = Path(key_left).parts[0]
        if not name_sequence in names_sequence:
            names_sequence.append(name_sequence)

    # Output H5 pose files for each sequence
    for name_sequence in names_sequence:
        timestamps = np.loadtxt(args.path_image_folders /  name_sequence / 'timestamps.txt')
        create_output_directory(args.path_output_folder / name_sequence)
        h5_file_poses = h5py.File(args.path_output_folder / name_sequence / 'pseudo_ground_truth_poses.h5', 'w')
        group_poses_mono_left = h5_file_poses.create_group('poses_mono_left')
        group_poses_mono_left.attrs['ros_message_type'] = np.array('geometry_msgs/PoseStamped'.encode('ascii'),
            dtype=h5py.string_dtype('ascii'))
        group_poses_mono_left.attrs['parent frame'] = 'left monochrome camera frame'
        group_poses_mono_left.attrs['child frame'] = 'COLMAP world frame'
        group_poses_mono_left.attrs['scale factor'] = scale_factor
        group_poses_mono_left.attrs['median translation error (meters)'] = np.median(errors_translation)
        group_poses_mono_left.attrs['mean translation error (meters)'] = np.mean(errors_translation)
        group_poses_mono_left.attrs['max translation error (meters)'] = np.max(errors_translation)
        group_poses_mono_left.attrs['stdev translation error (meters)'] = np.std(errors_translation)
        group_poses_mono_left.attrs['median rotation error (degrees)'] = np.median(errors_rotation)
        group_poses_mono_left.attrs['mean rotation error (degrees)'] = np.mean(errors_rotation)
        group_poses_mono_left.attrs['max rotation error (degrees)'] = np.max(errors_rotation)
        group_poses_mono_left.attrs['stdev rotation error (degrees)'] = np.std(errors_rotation)
        dataset_positions = group_poses_mono_left.create_dataset(name='positions', shape=(len(timestamps), 3),
            dtype=float)
        dataset_positions.attrs['units'] = 'meters'
        dataset_positions.attrs['column order'] = 'x, y, z'
        dataset_quaternions = group_poses_mono_left.create_dataset(name='quaternions', shape=(len(timestamps), 4),
            dtype=float)
        dataset_quaternions.attrs['column order'] = 'x, y, z, w'
        dataset_timestamps = group_poses_mono_left.create_dataset(name='timestamps', shape=(len(timestamps),),
            dtype='u8')
        dataset_timestamps.attrs['units'] = 'nanoseconds'
        for key_left in transformations_world_to_mono_left:
            if Path(key_left).parts[0] != name_sequence:
                continue

            transformation_world_to_mono_left = transformations_world_to_mono_left[key_left]
            quaternion = Rotation.from_matrix(transformation_world_to_mono_left[:3, :3]).as_quat()
            position = transformation_world_to_mono_left[:3, 3]

            index_image = int(key_left[-11:-4])
            timestamp = timestamps[index_image]

            dataset_positions[index_image] = position * scale_factor
            dataset_quaternions[index_image] = quaternion
            dataset_timestamps[index_image] = timestamp
