import argparse
import cv2
import numpy as np

from trnerf_utils import create_output_directory, open_h5_image_file

if __name__ == "__main__":
    # Process arguments
    parser = argparse.ArgumentParser()
    parser.add_argument('--path-input-folder', type=str, help='Path to input folder containing H5 files.')
    parser.add_argument('--path-output-folder', type=str, help='Path to output folder.')
    parser.add_argument('--n-images-colmap', type=int, help='Number of images to select for COLMAP.')
    parser.add_argument('--t-start', type=float, help='Timestamp at which to start selecting images.')
    parser.add_argument('--t-stop', type=float, help='Timestamp at which to stop selecting images.')

    args = parser.parse_args()

    # Open H5 files
    names = ['adk_left', 'adk_right', 'mono_left', 'mono_right']
    image_data_dicts = [open_h5_image_file(f'{args.path_input_folder}/{name}.h5') for name in names]

    # Create output directories
    for image_data_dict in image_data_dicts:
        create_output_directory(f"{args.path_output_folder}/{image_data_dict['name']}/")

    # Determine timestamps, within the selected range, for which there are no missing frames from any of the cameras
    timestamps_all_cams = image_data_dicts[0]['timestamps']
    for i in range(1, len(image_data_dicts)):
        timestamps_all_cams = np.intersect1d(timestamps_all_cams, image_data_dicts[i]['timestamps'])
    timestamps_all_cams = timestamps_all_cams[timestamps_all_cams >= args.t_start * 1e9]
    timestamps_all_cams = timestamps_all_cams[timestamps_all_cams <= args.t_stop * 1e9]

    # Write out all images
    for i, timestamp in enumerate(timestamps_all_cams):
        for image_data_dict in image_data_dicts:
            index_image = np.argwhere(image_data_dict['timestamps'] == timestamp)[0][0]
            image = image_data_dict['images'][index_image]

            filename =  f"{image_data_dict['name']}_%07d.png" % i
            cv2.imwrite(f"{args.path_output_folder}/{image_data_dict['name']}/{filename}", image)

    # Write out timestamps
    timestamp_file = open(f'{args.path_output_folder}/timestamps.txt', 'w')
    timestamp_file.write('\n'.join(str(time) for time in timestamps_all_cams))
    timestamp_file.close()

    # Write out COLMAP and HLOC image lists
    for image_data_dict in image_data_dicts:
        name = image_data_dict['name']
        image_list = [f"{name}/{name}_%07d.png" % i for i in range(len(timestamps_all_cams))]
        if name == 'mono_left':
            step = int(np.round(len(image_list) /  args.n_images_colmap))
            image_list_colmap = image_list[0::step]

            image_list_file_colmap = open(f"{args.path_output_folder}/image_list_{name}_colmap.txt", 'w')
            image_list_file_colmap.write('\n'.join(relative_path for relative_path in image_list_colmap))
            image_list_file_colmap.close()

            image_list_hloc = \
                [relative_path for relative_path in image_list if not (relative_path in image_list_colmap)]

            image_list_file_hloc = open(f"{args.path_output_folder}/image_list_{name}_hloc.txt", 'w')
            image_list_file_hloc.write('\n'.join(relative_path for relative_path in image_list_hloc))
            image_list_file_hloc.close()
        elif name == 'mono_right':
            image_list_file_hloc = open(f"{args.path_output_folder}/image_list_{name}_hloc.txt", 'w')
            image_list_file_hloc.write('\n'.join(relative_path for relative_path in image_list))
            image_list_file_hloc.close()
