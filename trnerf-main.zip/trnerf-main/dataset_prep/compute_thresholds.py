import argparse
from pathlib import Path
from tqdm import tqdm
import numpy as np

from trnerf_utils import open_h5_image_file, open_h5_pose_file

if __name__ == "__main__":
    # Process arguments
    parser = argparse.ArgumentParser(description="Compute 16-bit and 8-bit thresholds.")
    parser.add_argument('--paths-image-file', nargs='+', type=Path, help='Paths to H5 files with the thermal images to '
        'process')
    parser.add_argument('--paths-poses', nargs='+', type=Path, help='Paths to pseudo ground truth pose files. These '
        'are used only to determine the timestamps for the images to process.')

    args = parser.parse_args()

    # Read in images
    images_all = []
    for path_image_file, path_pose_file in zip(args.paths_image_file, args.paths_poses):
        timestamps = open_h5_pose_file(path_pose_file)['timestamps']
        image_data_dict = open_h5_image_file(path_image_file)
        for timestamp in tqdm(timestamps):
            index_image = np.argwhere(image_data_dict['timestamps'] == timestamp)[0][0]
            image = image_data_dict['images'][index_image]
            images_all.append(image)
    images_all = np.array(images_all)

    # Compute thresholds
    min_val = np.min(images_all)
    max_val = np.max(images_all)
    percentile_low = np.percentile(images_all, 0.1)
    percentile_high = np.percentile(images_all, 99.9)

    print(f'Min: {min_val}, Max: {max_val}')
    print(f'0.1 Percentile: {percentile_low}, 99.9 Percentile: {percentile_high}')
