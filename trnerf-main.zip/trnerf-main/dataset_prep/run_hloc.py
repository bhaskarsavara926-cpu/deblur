from pathlib import Path
from tqdm import tqdm
import pycolmap
import functools
from math import ceil
import pickle
import argparse
import multiprocessing

from hloc import extract_features, match_features, pairs_from_covisibility, pairs_from_retrieval, pairs_from_exhaustive, triangulation
from hloc.utils.parsers import parse_retrieval
from hloc.localize_sfm import QueryLocalizer, do_covisibility_clustering, pose_from_cluster

from trnerf_utils import create_output_directory, read_yaml

def read_image_list(path_image_list):
    file_image_list = open(path_image_list, "r")
    data_image_list = file_image_list.read()
    file_image_list.close()

    image_list = data_image_list.split("\n")
    image_list = [Path(p) for p in image_list]

    return image_list

def localize_query(image_name_query, pairs_query, hloc_model, image_name_reference_to_id, covisibility_clustering,
        localizer, path_local_features_query, path_matches_query, calibration_results):
    camera_name_query = str(image_name_query.parts[-2])
    for key in calibration_results:
        if camera_name_query in calibration_results[key]['rostopic'].replace('/', '_'):
            calibration_result = calibration_results[key]
    camera_params = calibration_result['intrinsics'] + calibration_result['distortion_coeffs']
    camera_params[2] += 0.5 # Add 0.5 to principal point due to differing conventions btw. Kalibr and COLMAP
    camera_params[3] += 0.5
    camera_query = pycolmap.Camera(
        model='OPENCV',
        width=int(calibration_result['resolution'][0]),
        height=int(calibration_result['resolution'][1]),
        params=camera_params)

    image_name_query = str(image_name_query)
    if image_name_query not in pairs_query:
        return None

    image_names_reference = pairs_query[image_name_query]
    image_ids_reference = [image_name_reference_to_id[image_name_reference] for image_name_reference in
        image_names_reference]

    pose = None
    if covisibility_clustering:
        clusters = do_covisibility_clustering(image_ids_reference, hloc_model)
        n_inliers_max = 0
        for image_ids_reference_cluster in clusters:
            ret, _ = pose_from_cluster(
                localizer,
                image_name_query,
                camera_query,
                image_ids_reference_cluster,
                path_local_features_query,
                path_matches_query)
            if ret['success'] and ret['num_inliers'] > n_inliers_max:
                pose = (ret['qvec'], ret['tvec'])
                n_inliers_max = ret['num_inliers']
    else:
        ret, _ = pose_from_cluster(
                localizer,
                image_name_query,
                camera_query,
                image_ids_reference,
                path_local_features_query,
                path_matches_query)
        if ret['success']:
            pose = (ret['qvec'], ret['tvec'])

    return pose

def localize_queries(image_list_query, config_localizer, path_hloc_model, path_pairs_query, path_local_features_query,
        path_matches_query, covisibility_clustering, calibration_results):
    hloc_model = pycolmap.Reconstruction(path_hloc_model)
    image_name_reference_to_id = {image.name: image_id for image_id, image in hloc_model.images.items()}
    pairs_query = parse_retrieval(path_pairs_query)
    localizer = QueryLocalizer(hloc_model, config_localizer)

    poses = {}
    for image_name_query in tqdm(image_list_query):
        pose = localize_query(image_name_query, pairs_query, hloc_model, image_name_reference_to_id,
            covisibility_clustering, localizer, path_local_features_query, path_matches_query, calibration_results)
        if pose:
            poses[str(image_name_query)] = pose

    return poses

if __name__ == "__main__":
    # Process arguments
    parser = argparse.ArgumentParser(description="Localize query images against an existing COLMAP result.")
    parser.add_argument('--path-colmap-model', type=Path, help='Path to existing COLMAP model folder.')
    parser.add_argument('--path-reference-image-list', type=Path,
        help='Path to reference image list used to create the existing COLMAP model.')
    parser.add_argument('--path-query-image-list', type=Path,
        help='Path to query image list. All images in this list will be localized.')
    parser.add_argument('--path-image-parent-folder', type=Path,
        help='Path to the parent folder the image paths in the images lists are relative to.')
    parser.add_argument("--path-calibration-results", type=str, help="Path to Kalibr camchain YAML file.")
    parser.add_argument('--path-outputs', type=Path, help='Path to the output folder.')
    parser.add_argument('--local-feature-extractor', type=str, default='disk',
        help="The local feature extractor (default = 'disk'). Options: superpoint_aachen, superpoint_max, "
        "superpoint_inloc, r2d2, d2net-ss, sift, sosnet, disk.")
    parser.add_argument('--local-feature-matcher', type=str, default='disk+lightglue',
        help="The local feature matcher to use (default = 'disk+lightglue'). Options: superpoint+lightglue, "
        "disk+lightglue, superglue, superglue-fast, NN-superpoint, NN-ratio, NN-mutual, adalam.")
    parser.add_argument('--global-descriptor', type=str, default='netvlad',
        help="The global descriptor type used for retrieval (ignored if exhaustive is True) (default = 'netvlad'). "
        "Options: dir, netvlad, openibl, cosplace.")
    parser.add_argument('--n-pairs', type=int, default=20,
        help="Number of top matches returned from retrieval to perform local matching with (default: 20).")
    parser.add_argument('--exhaustive', action='store_true',
        help='If set, matching is performed between each query and every reference rather than the top n_pairs '
        'references returned by retrieval. Note this will be very slow if the number of references is >> n_pairs.')
    parser.add_argument('--overwrite', action='store_true',
        help='If set, previously computed results in output h5 files will be recomputed and overwritten.')
    parser.add_argument('--covisibility_clustering', action='store_true',
        help='If set, covisibility clustering will be utilized during localization. Note this is substantially slower.')
    parser.add_argument('--parallel', action='store_true',
        help='If set, localization will be run across multiple processes.')

    args = parser.parse_args()

    # Create output folder
    create_output_directory(args.path_outputs)

    # Set configs
    config_local_feature_extractor = extract_features.confs[args.local_feature_extractor]
    config_local_feature_matcher = match_features.confs[args.local_feature_matcher]
    config_global_descriptor = extract_features.confs[args.global_descriptor]
    config_localizer = {
        'estimation': {'estimate_focal_length': False, 'ransac': {'max_error': 12}},
        'refinement': {'refine_focal_length': False, 'refine_extra_params': False}}

    # Set additional parameters
    n_pairs = args.n_pairs
    exhaustive = args.exhaustive
    overwrite = args.overwrite
    covisibility_clustering = args.covisibility_clustering
    parallel = args.parallel

    ## Create new sparse reconstruction

    # Set derived paths
    path_local_features_reference = args.path_outputs / 'local_features_reference.h5'
    path_global_features_reference = args.path_outputs / 'global_features_reference.h5'
    path_pairs_reference = args.path_outputs / 'pairs_reference.txt'
    path_matches_reference = args.path_outputs / 'matches_reference.h5'
    path_hloc_model = args.path_outputs / 'sparse/0/'

    # Extract local features for reference images
    image_list_reference = read_image_list(args.path_reference_image_list)
    extract_features.main(
        conf=config_local_feature_extractor,
        image_dir=args.path_image_parent_folder,
        as_half=False,
        image_list=image_list_reference,
        feature_path=path_local_features_reference,
        overwrite=overwrite)

    if not exhaustive:
        # Compute global descriptors for reference images
        extract_features.main(
            conf=config_global_descriptor,
            image_dir=args.path_image_parent_folder,
            as_half=False,
            image_list=image_list_reference,
            feature_path=path_global_features_reference,
            overwrite=overwrite)

    # Generate reference pairs from existing COLMAP sparse reconstruction
    pairs_from_covisibility.main(
        model=args.path_colmap_model,
        output=path_pairs_reference,
        num_matched=n_pairs)

    # Compute matches between reference images
    match_features.main(
        conf=config_local_feature_matcher,
        pairs=path_pairs_reference,
        features=path_local_features_reference,
        matches=path_matches_reference,
        overwrite=overwrite)

    # Triangulate new sparse reconstruction from the COLMAP poses and the newly computed matches
    triangulation.main(
        sfm_dir=path_hloc_model,
        reference_model=args.path_colmap_model,
        image_dir=args.path_image_parent_folder,
        pairs=path_pairs_reference,
        features=path_local_features_reference,
        matches=path_matches_reference)

    ## Localize query images

    # Set derived paths
    path_local_features_query = args.path_outputs / 'local_features_query.h5'
    path_global_features_query = args.path_outputs / 'global_features_query.h5'
    path_pairs_query = args.path_outputs / 'pairs_query.txt'
    path_matches_query = args.path_outputs / 'matches_query.h5'

    # Read in query image list
    image_list_query = read_image_list(args.path_query_image_list)

    # Extract local features for query images
    extract_features.main(
        conf=config_local_feature_extractor,
        image_dir=args.path_image_parent_folder,
        as_half=False,
        image_list=image_list_query,
        feature_path=path_local_features_query,
        overwrite=overwrite)

    if not exhaustive:
        # Compute global descriptors for query images
        extract_features.main(
            conf=config_global_descriptor,
            image_dir=args.path_image_parent_folder,
            as_half=False,
            image_list=image_list_query,
            feature_path=path_global_features_query,
            overwrite=overwrite)

        # Compute pairs between query and reference images
        pairs_from_retrieval.main(
            descriptors=path_global_features_query,
            output=path_pairs_query,
            num_matched=n_pairs,
            db_descriptors=path_global_features_reference)
    else:
        # Write out all possible pairs between each query and every reference
        pairs_from_exhaustive.main(
            output=path_pairs_query,
            image_list=[str(image_name) for image_name in image_list_query],
            ref_list=[str(image_name) for image_name in image_list_reference])

    # Compute matches between query and reference images
    match_features.main(
        conf=config_local_feature_matcher,
        pairs=path_pairs_query,
        features=path_local_features_query,
        matches=path_matches_query,
        features_ref=path_local_features_reference,
        overwrite=overwrite)

    # Read in calibration results
    calibration_results = read_yaml(args.path_calibration_results)

    # Localize the query images
    print('Localizing query images...')
    if parallel:
        # Note: we launch multiple processes running localize_queries() with separate query image lists instead of
        # parallelizing the for loop in localize_queries() because pycolmap.Reconstruction cannot be pickled.
        # Unfortunately this means each process needs to independently read in the hloc_model.
        localize_queries_fixed_inputs = functools.partial(localize_queries,
            config_localizer=config_localizer,
            path_hloc_model=path_hloc_model,
            path_pairs_query=path_pairs_query,
            path_local_features_query=path_local_features_query,
            path_matches_query=path_matches_query,
            covisibility_clustering=covisibility_clustering,
            calibration_results=calibration_results)

        n_cores = multiprocessing.cpu_count()
        n_image_per_core = ceil(len(image_list_query) / n_cores)
        index = 0
        image_lists_query = []
        while index + n_image_per_core < len(image_list_query):
            image_lists_query.append(image_list_query[index:index + n_image_per_core])
            index += n_image_per_core
        image_lists_query.append(image_list_query[index:])
        with multiprocessing.Pool() as pool:
            poses = {}
            for poses_subset in pool.map(localize_queries_fixed_inputs, image_lists_query):
                poses.update(poses_subset)
    else:
        poses = localize_queries(
            image_list_query,
            config_localizer,
            path_hloc_model,
            path_pairs_query,
            path_local_features_query,
            path_matches_query,
            covisibility_clustering,
            calibration_results=calibration_results)
    print(f'Successfully localized {len(poses)} images out of {len(image_list_query)}')

    # Write out the poses
    path_output_poses = args.path_outputs / 'poses_query.pickle'
    pickle.dump(poses, open(path_output_poses, 'wb'))
    print(f'The localized poses have been written to: {str(path_output_poses)}')
