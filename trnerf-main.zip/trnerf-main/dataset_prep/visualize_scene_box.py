import argparse
from pathlib import Path
import h5py
import numpy as np
from scipy.spatial.transform import Rotation
import mpl_toolkits.mplot3d.art3d as art3d
import matplotlib.pyplot as plt

from trnerf_utils import read_yaml, open_h5_pose_file, to_transformations, get_transformation_from_calib, \
    invert_transformation_matrix

# Requires a file from COLMAP: https://github.com/colmap/colmap/blob/main/scripts/python/read_write_model.py
from read_write_model import read_points3D_binary

if __name__ == "__main__":
    # Process arguments
    parser = argparse.ArgumentParser()
    parser.add_argument('--path-poses', type=Path, help='Path to pseudo ground truth pose file.')
    parser.add_argument('--path-colmap-model', type=Path, help='Path to COLMAP model folder.')
    parser.add_argument("--name-camera", type=str, help='Name of camera to be visualized.')
    parser.add_argument("--path-calibration-results", type=Path, help='Path to Kalibr camchain YAML file.')
    parser.add_argument("--rotation", nargs='+', type=float, help='Rotation to apply to the poses.')
    parser.add_argument("--translation", nargs='+', type=float, help='Translation to apply to the poses.')
    parser.add_argument("--scale-factor", type=float, help='Scaling to apply to the poses.')

    args = parser.parse_args()

    ####################################################################################################################
    # Identical to trnerf_dataparser.py
    ####################################################################################################################

    # Read in calibration results
    calibration_results = read_yaml(args.path_calibration_results)

    # Read in pose data
    pose_data_dict = open_h5_pose_file(args.path_poses)

    # Convert pose data to transformation matrices
    poses_world_to_mono_left = to_transformations(pose_data_dict['positions'], pose_data_dict['quaternions'])

    # Transform poses to the camera frame corresponding to the input images and invert
    transformation_mono_left_to_camera = get_transformation_from_calib(calibration_results, 'mono_left',
        args.name_camera)
    poses_world_to_camera = transformation_mono_left_to_camera @ poses_world_to_mono_left
    poses_camera_to_world = np.asarray([invert_transformation_matrix(pose_world_to_camera)
        for pose_world_to_camera in poses_world_to_camera])

    # Convert from the current camera frame convention (x right, y down, z forward) to the OpenGL camera frame
    # convention (x right, y up, z back)
    # Equivalent to right multiplying the poses with transformation_cgl_to_camera (cgl = camera OpenGL):
    # [[1,  0,  0,  0],
    #  [0, -1,  0,  0],
    #  [0,  0, -1,  0],
    #  [0,  0,  0,  1]]
    poses_cgl_to_world = np.copy(poses_camera_to_world)
    poses_cgl_to_world[:, :, 1:3] *= -1

    # Transform the world frame from the COLMAP convention (x right, y down, z forward -- assuming the initial
    # camera pose is parallel to the ground) to the nerfstudio viewer convention (x right, y forward, z up)
    # Equivalent to left multiplying the poses with transformation_world_to_wv (wv = world viewer):
    # [[1,  0,  0,  0],
    #  [0,  0,  1,  0],
    #  [0, -1,  0,  0],
    #  [0,  0,  0,  1]]
    poses_cgl_to_wv = poses_cgl_to_world[:, np.array([0, 2, 1, 3]), :]
    poses_cgl_to_wv[:, 2, :] *= -1

    # Reorient and recenter the poses, i.e. transform them into a final world frame (wf = world final)
    transformation_wv_to_wf = np.eye(4)
    transformation_wv_to_wf[:3, :3] = \
        Rotation.from_euler('xyz', np.array(args.rotation), degrees=True).as_matrix()
    transformation_wv_to_wf[:3, 3] -= np.mean(poses_cgl_to_wv[:, :3, 3], axis=0)
    transformation_wv_to_wf[:3, 3] += np.array(args.translation)
    transformation_wv_to_wf = transformation_wv_to_wf[:3, :]
    poses_cgl_to_wf = transformation_wv_to_wf @ poses_cgl_to_wv

    # Compute the transformation from the COLMAP world frame to the final world frame
    transformation_world_to_wv = np.array([[1, 0, 0, 0], [0, 0, 1, 0], [0, -1, 0, 0], [0, 0, 0, 1]])
    transformation_world_to_wf = transformation_wv_to_wf @ transformation_world_to_wv

    # Scale the poses
    poses_cgl_to_wf_scaled = np.copy(poses_cgl_to_wf)
    poses_cgl_to_wf_scaled[:, :3, 3] *= args.scale_factor

    ####################################################################################################################

    # Read in the scale factor (that scales the COLMAP model to absolute scale)
    h5_file_pose = h5py.File(args.path_poses, 'r')
    pose_scale_factor = h5_file_pose['poses_mono_left'].attrs['scale factor']

    # Read in and scale the COLMAP point cloud
    points3D = read_points3D_binary(args.path_colmap_model / 'points3D.bin')
    xyz_points = []
    for id_point, point3D in points3D.items():
        xyz_scaled = point3D.xyz * pose_scale_factor
        xyz_points.append(xyz_scaled)
    xyz_points = np.array(xyz_points)

    # Transform the point cloud from the COLMAP world frame to the final world frame
    xyz_points = (transformation_world_to_wf[:3, :3] @ xyz_points.T +
        np.expand_dims(transformation_world_to_wf[:3, 3], axis=1)).T
    xyz_points *= args.scale_factor

    # Plot the point cloud
    fig3d = plt.figure()
    ax3d = fig3d.add_subplot(projection='3d')
    ax3d.scatter(
        xyz_points[::10, 0],
        xyz_points[::10, 1],
        xyz_points[::10, 2],
        'b',
        s=0.3)

    # Plot the poses
    ax3d.plot(
        poses_cgl_to_wf_scaled[:, 0, 3],
        poses_cgl_to_wf_scaled[:, 1, 3],
        poses_cgl_to_wf_scaled[:, 2, 3], 'r')
    for i in range(0, len(poses_cgl_to_wf_scaled), 100):
        pose = poses_cgl_to_wf_scaled[i]
        x_arrow = pose[:3, :3].dot(np.array([0.1, 0, 0]))
        y_arrow = pose[:3, :3].dot(np.array([0, 0.1, 0]))
        z_arrow = pose[:3, :3].dot(np.array([0, 0, 0.1]))

        ax3d.quiver(
            pose[0, 3], pose[1, 3], pose[2, 3],
            x_arrow[0], x_arrow[1], x_arrow[2],
            color = 'red')
        ax3d.quiver(
            pose[0, 3], pose[1, 3], pose[2, 3],
            y_arrow[0], y_arrow[1], y_arrow[2],
            color = 'green')
        ax3d.quiver(
            pose[0, 3], pose[1, 3], pose[2, 3],
            z_arrow[0], z_arrow[1], z_arrow[2],
            color = 'blue')

    # Draw the scene box (a cube with side length 2 centered about the origin of the final world frame)
    cube = art3d.Poly3DCollection(
        verts=[
            np.array([[-1, -1, -1], [1, -1, -1], [-1, 1, -1], [1, 1, -1]]),
            np.array([[-1, -1, -1], [1, -1, -1], [1, -1, 1], [-1, -1, 1]]),
            np.array([[-1, -1, -1], [-1, 1, -1], [-1, 1, 1], [-1, -1, 1]]),
            np.array([[-1, -1, 1], [1, -1, 1], [-1, 1, 1], [1, 1, 1]]),
            np.array([[-1, 1, -1], [1, 1, -1], [1, 1, 1], [-1, 1, 1]]),
            np.array([[1, -1, -1], [1, 1, -1], [1, 1, 1], [1, -1, 1]])],
        facecolors=[1, 1, 1, 0.5],
        shade=True)
    ax3d.add_collection3d(cube)

    ax3d.set_xlim(-1.5, 1.5)
    ax3d.set_ylim(-1.5, 1.5)
    ax3d.set_zlim(-1.5, 1.5)

    ax3d.set_xlabel("x")
    ax3d.set_ylabel("y")
    ax3d.set_zlabel("z")
    ax3d.set_aspect('equal')

    plt.show()
