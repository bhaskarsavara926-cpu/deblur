import argparse
from pathlib import Path

if __name__ == "__main__":
    # Process arguments
    parser = argparse.ArgumentParser()
    parser.add_argument('--paths-file-to-combine', nargs='+', type=str, help='Image list files to combine.')
    parser.add_argument('--path-output-file', type=str, help='Path to combined output file.')
    args = parser.parse_args()

    with open(args.path_output_file, 'w') as file_combined:
        for i, path_file_to_combine in enumerate(args.paths_file_to_combine):
            if i > 0:
                file_combined.write('\n')
            folder_parent = Path(path_file_to_combine).parts[-2]
            with open(path_file_to_combine) as file_to_combine:
                for line in file_to_combine:
                    file_combined.write(f'{folder_parent}/{line}')
