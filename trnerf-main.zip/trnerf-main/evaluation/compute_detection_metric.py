"""
Compute the Aprilgrid detection metric
"""

import numpy as np
import argparse
from tqdm import tqdm
from pathlib import Path
import pickle
import multiprocessing
import functools
from math import ceil

# Kalibr
import aslam_cv as acv
import aslam_cameras_april as acv_april
import kalibr_common as kc

from trnerf_utils import read_yaml, get_transformation_from_calib, get_camera_index, open_h5_pose_file, \
    open_h5_image_file, get_ideal_camera_matrix_and_undist_map, read_image_at_timestamp

def setup_camera_geometry_and_grid_detector(path_calibration_results, name_camera, path_grid_config,
    min_tags_for_valid_observation=None, camera_matrix_ideal=None):
    # Setup camera geometry
    index_camera = get_camera_index(read_yaml(path_calibration_results), name_camera)
    camera_parameters = \
        kc.ConfigReader.CameraChainParameters(path_calibration_results).getCameraParameters(index_camera)
    if not camera_matrix_ideal is None:
        camera_parameters.data['intrinsics'] = \
            [camera_matrix_ideal[0, 0], camera_matrix_ideal[1, 1], camera_matrix_ideal[0, 2], camera_matrix_ideal[1, 2]]
        camera_parameters.data['distortion_coeffs'] = [0.0, 0.0, 0.0, 0.0]
    camera_geometry = kc.ConfigReader.AslamCamera.fromParameters(camera_parameters).geometry

    # Setup grid detector
    grid_params = kc.ConfigReader.CalibrationTargetParameters(path_grid_config).getTargetParams()
    options_april_grid = acv_april.AprilgridOptions()
    if min_tags_for_valid_observation:
        options_april_grid.minTagsForValidObs = min_tags_for_valid_observation
    grid_object = acv_april.GridCalibrationTargetAprilgrid(grid_params['tagRows'], grid_params['tagCols'],
        grid_params['tagSize'], grid_params['tagSpacing'], options_april_grid)
    grid_detector = acv.GridDetector(camera_geometry, grid_object)

    return camera_geometry, grid_detector

def get_corners_from_observations(observations):
    corners_image_frame = observations.getCornersImageFrame()
    ids_corner = observations.getCornersIdx()

    corners_image_frame_dict = {}
    for id_corner, corner_image_frame in zip(ids_corner, corners_image_frame):
        corners_image_frame_dict[id_corner] = corner_image_frame

    return corners_image_frame_dict

def compute_detection_metric(grid_detector_mono_left, image_mono_left, camera_geometry_thermal, grid_detector_thermal,
    image_thermal, transformation_mono_left_to_thermal, ids_tag_row_ignore):
    # Get 3D coordinates for all grid corners in the grid frame
    # Note: these coordinates are constant and derived from the grid config. The coordinates are returned as a Nx3
    # matrix where N is the number of corners on the grid. There are four corners per AprilTag, so
    # N = 4 * tagRows * tagCols. See the Kalibr function GridCalibrationTargetAprilgrid::createGridPoints() for how the
    # grid coordinates are computed.
    corners_grid_frame_all = grid_detector_mono_left.target().points()

    # Detect corners in both images
    success_mono_left, observations_mono_left = grid_detector_mono_left.findTarget(image_mono_left)
    corners_mono_left_image_frame = get_corners_from_observations(observations_mono_left)
    _, observations_thermal = grid_detector_thermal.findTargetNoTransformation(image_thermal)
    corners_thermal_image_frame = get_corners_from_observations(observations_thermal)

    if not success_mono_left:
        # If the grid detection or PnP pose estimation failed in the monochrome image, the detection metric can't be
        # computed
        return corners_mono_left_image_frame, corners_thermal_image_frame, None
    else:
        # Transform all grid corners into the thermal image frame, using the transformation estimated between the
        # grid and mono left camera frame
        corners_thermal_image_frame_reprojected = {}
        transformation_grid_to_mono_left = observations_mono_left.T_t_c().inverse().T()
        transformation_grid_to_thermal = transformation_mono_left_to_thermal @ transformation_grid_to_mono_left
        for id_corner in range(corners_grid_frame_all.shape[0]):
            # Transform the corner from the grid frame to the thermal camera frame
            corner_grid_frame = corners_grid_frame_all[id_corner].T
            corner_thermal_camera_frame = transformation_grid_to_thermal[:3, :3] @ corner_grid_frame + \
                transformation_grid_to_thermal[:3, 3]

            # Transform the corner from the thermal camera frame to the thermal image frame by applying the thermal
            # camera intrinsics
            corner_thermal_image_frame_reprojected = \
                camera_geometry_thermal.euclideanToKeypoint(corner_thermal_camera_frame)

            # Reject corners that fall outside the image or too near the borders
            min_border_distance = 4 # This is the default in Kalibr's AprilgridOptions
            if corner_thermal_image_frame_reprojected[0] < min_border_distance or \
               corner_thermal_image_frame_reprojected[0] > (image_thermal.shape[1] - min_border_distance) or \
               corner_thermal_image_frame_reprojected[1] < min_border_distance or \
               corner_thermal_image_frame_reprojected[1] > (image_thermal.shape[0] - min_border_distance):
                continue

            corners_thermal_image_frame_reprojected[id_corner] = corner_thermal_image_frame_reprojected

        # Reject corners from tags that are ignored, invalid, or only partially visible in the thermal image
        # Note: the ordering of the corner IDs relative to the tag IDs is shown below, using a 2x2 grid of tags as an
        # example
        #        12-----13  14-----15
        #        | TAG 2 |  | TAG 3 |
        #        8-------9  10-----11
        #        4-------5  6-------7
        #  y     | TAG 0 |  | TAG 1 |
        # ^      0-------1  2-------3
        # |-->x
        n_rows_grid = grid_detector_mono_left.target().rows() # Number of rows of corners (2x that of tags)
        n_cols_grid = grid_detector_mono_left.target().cols() # Number of columns of corners (2x that of tags)
        corners_thermal_image_frame_reprojected_ignored = {}
        for id_tag in range(int(n_rows_grid * n_cols_grid / 4)):
            # Determine if the tag is from an ignored row
            id_tag_row = id_tag // (n_cols_grid / 2)
            is_ignored = id_tag_row in ids_tag_row_ignore

            # Determine if the tag is from the first row (our Aprilgrid has the first row cut off, so we additionally
            # remove corners from that row)
            is_first_row = id_tag_row == 0

            # Determine if the tag is fully visible
            id_tag_base = id_tag_row * n_cols_grid * 2 + (id_tag % (n_cols_grid / 2)) * 2 # First corner of the tag
            ids_tag_corner = [id_tag_base, id_tag_base + 1, id_tag_base + n_cols_grid, id_tag_base + n_cols_grid + 1]
            is_fully_visible = True
            for id_tag_corner in ids_tag_corner:
                is_fully_visible = is_fully_visible and (id_tag_corner in corners_thermal_image_frame_reprojected)

            # Remove ignored, invalid, and partially visible tags
            if not is_fully_visible or is_first_row or is_ignored:
                for id_tag_corner in ids_tag_corner:
                    if id_tag_corner in corners_thermal_image_frame_reprojected:
                        # Retain corners that were ignored for plotting
                        if is_fully_visible and is_ignored:
                            corners_thermal_image_frame_reprojected_ignored[id_tag_corner] = \
                                corners_thermal_image_frame_reprojected[id_tag_corner]
                        del corners_thermal_image_frame_reprojected[id_tag_corner]

        # Store reprojection data
        detection_data = {}
        detection_data['transformation_grid_to_thermal'] = transformation_grid_to_thermal
        detection_data['corners_thermal_image_frame_reprojected'] = corners_thermal_image_frame_reprojected
        detection_data['corners_thermal_image_frame_reprojected_ignored'] = \
            corners_thermal_image_frame_reprojected_ignored

        # Compute detection percentage and related stats
        if len(corners_thermal_image_frame_reprojected) != 0:
            ids_corner_common = np.intersect1d(np.array(list(corners_thermal_image_frame.keys())),
                np.array(list(corners_thermal_image_frame_reprojected.keys())))
            detection_data['ids_corner_common'] = ids_corner_common
            detection_data['percent_detected'] = \
                (len(ids_corner_common) / len(corners_thermal_image_frame_reprojected)) * 100
            detection_data['reprojection_errors'] = []
            for id_corner in ids_corner_common:
                detection_data['reprojection_errors'].append(np.linalg.norm(
                    corners_thermal_image_frame[id_corner] - corners_thermal_image_frame_reprojected[id_corner]))

        return corners_mono_left_image_frame, corners_thermal_image_frame, detection_data

def process_images_at_timestamps(timestamps, path_mono_left, path_thermal_images, undistortion_map_1_thermal,
    undistortion_map_2_thermal, grid_detector_mono_left, camera_geometry_thermal, grid_detector_thermal,
    transformation_mono_left_to_thermal, ids_tag_row_ignore, threshold_minimum, threshold_maximum):
    # Open H5 image files
    image_data_dict_mono_left = open_h5_image_file(path_mono_left)
    image_data_dict_thermal = open_h5_image_file(path_thermal_images)

    # Loop through timestamps and process images
    results = {}
    for timestamp in tqdm(timestamps):
        # Read in the images
        image_mono_left = read_image_at_timestamp(timestamp, image_data_dict_mono_left)
        image_thermal = read_image_at_timestamp(timestamp, image_data_dict_thermal, threshold_minimum,
            threshold_maximum, undistortion_map_1=undistortion_map_1_thermal,
            undistortion_map_2=undistortion_map_2_thermal)

        # Invert the thermal image for AprilTag detection
        image_thermal = 255 - image_thermal

        # Compute the detection metric
        corners_mono_left, corners_thermal, detection_data = compute_detection_metric(grid_detector_mono_left,
            image_mono_left, camera_geometry_thermal, grid_detector_thermal, image_thermal,
            transformation_mono_left_to_thermal, ids_tag_row_ignore)

        results[timestamp] = {
            'corners_mono_left': corners_mono_left,
            'corners_thermal': corners_thermal,
            'detection_data': detection_data}

    return results

if __name__ == "__main__":
    # Process arguments
    parser = argparse.ArgumentParser(description="Evaluate image quality based on Aprilgrid detections.")
    parser.add_argument("--path-thermal-images", type=Path, help="Path to H5 file with the thermal images to evaluate.")
    parser.add_argument("--threshold-minimum", type=float, default=0.0, help="Min threshold used for remapping thermal "
        "images. Ignored if the thermal images are 8-bit.")
    parser.add_argument("--threshold-maximum", type=float, default=(2**16 - 1), help="Max threshold used for remapping "
        "thermal images. Ignored if the thermal images are 8-bit.")
    parser.add_argument("--name-thermal", type=str, help="Thermal camera name.")
    parser.add_argument("--undistort-thermal", action='store_true', help="Whether to undistort the thermal images "
        "(needed to perform evaluation with the raw thermal images).")
    parser.add_argument("--path-mono-left", type=Path, help="Path to H5 file with the left monochrome images.")
    parser.add_argument("--path-poses", type=Path, help="Path to pseudo ground truth pose file. This is used only to "
        "determine the timestamps for evaluation (needed to perform evaluation with the raw thermal images).")
    parser.add_argument("--path-calibration-results", type=Path, help="Path to Kalibr camchain YAML file.")
    parser.add_argument("--path-grid-config", type=Path, help="Path to Aprilgrid config.")
    parser.add_argument("--ids-tag-row-ignore", nargs='+', type=int, default=[],
        help="Tag rows to ignore in the evaluation specified as space separated list. Defaults to an empty list.")
    parser.add_argument('--path-pickle-out-folder', type=Path, help="Path to the output folder for the results.")

    args = parser.parse_args()

    # Get the transformation from the left monochrome camera to the thermal camera
    calibration_results = read_yaml(args.path_calibration_results)
    transformation_mono_left_to_thermal = get_transformation_from_calib(calibration_results, 'mono_left',
        args.name_thermal)

    # Setup camera geometry and grid detectors for each camera
    # Note: we change the minTagsForValidObs of the thermal camera detector to 1, so all detected corners are returned.
    # For the mono left detector, we leave the minTagsForValidObs to the default of 4 to avoid attempting PnP pose
    # estimation with a small number of tags
    _, grid_detector_mono_left = setup_camera_geometry_and_grid_detector(
        args.path_calibration_results, 'mono_left', args.path_grid_config)
    camera_matrix_ideal_thermal, undistortion_map_1_thermal, undistortion_map_2_thermal = \
        get_ideal_camera_matrix_and_undist_map(calibration_results, args.name_thermal)
    camera_geometry_thermal, grid_detector_thermal = setup_camera_geometry_and_grid_detector(
        args.path_calibration_results, args.name_thermal, args.path_grid_config, 1, camera_matrix_ideal_thermal)

    # If the thermal images do not need to be undistorted, then the undistortion maps should not be applied
    if not args.undistort_thermal:
        undistortion_map_1_thermal = undistortion_map_2_thermal = None

    # Read in the evaluation timestamps from the pose file
    timestamps_evaluation = open_h5_pose_file(args.path_poses)['timestamps']

    # Launch multiple processes running process_images_at_timestamps() with separate timestamp lists and combine the
    # results
    # NOTE: this is done instead of parallelizing the for loop in process_images_at_timestamps() because h5py objects
    # cannot be pickled
    process_images_at_timestamps_fixed_inputs = functools.partial(process_images_at_timestamps,
        path_mono_left=args.path_mono_left,
        path_thermal_images=args.path_thermal_images,
        undistortion_map_1_thermal=undistortion_map_1_thermal,
        undistortion_map_2_thermal=undistortion_map_2_thermal,
        grid_detector_mono_left=grid_detector_mono_left,
        camera_geometry_thermal=camera_geometry_thermal,
        grid_detector_thermal=grid_detector_thermal,
        transformation_mono_left_to_thermal=transformation_mono_left_to_thermal,
        ids_tag_row_ignore=args.ids_tag_row_ignore,
        threshold_minimum=args.threshold_minimum,
        threshold_maximum=args.threshold_maximum)

    n_cores = multiprocessing.cpu_count()
    n_image_per_core = ceil(len(timestamps_evaluation) / n_cores)
    index = 0
    timestamps_evaluation_list = []
    while index + n_image_per_core < len(timestamps_evaluation):
        timestamps_evaluation_list.append(timestamps_evaluation[index:index + n_image_per_core])
        index += n_image_per_core
    timestamps_evaluation_list.append(timestamps_evaluation[index:])

    evaluation_data = {}
    evaluation_data['type'] = 'detection'
    evaluation_data['args'] = args
    evaluation_data['results'] = {}
    print('Computing detection metric...')
    with multiprocessing.Pool() as pool:
        for results in pool.map(process_images_at_timestamps_fixed_inputs, timestamps_evaluation_list):
            evaluation_data['results'].update(results)

    # Write out the results
    path_pickle_out = args.path_pickle_out_folder / 'results_detection_metric.pickle'
    pickle.dump(evaluation_data, open(path_pickle_out, 'wb'))
