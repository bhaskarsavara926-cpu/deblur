"""
Compute the LPIPS metric with pseudo ground truth images
"""

import numpy as np
import argparse
from tqdm import tqdm
from pathlib import Path
import pickle
from scipy.spatial.transform import Rotation

import torch
from torchmetrics.image.lpip import LearnedPerceptualImagePatchSimilarity

from trnerf_utils import read_yaml, get_transformation_from_calib, open_h5_pose_file, open_h5_image_file, \
    get_ideal_camera_matrix_and_undist_map, read_image_at_timestamp, to_transformations

import warnings
warnings.filterwarnings("ignore", category=FutureWarning)

if __name__ == "__main__":
    # Process arguments
    parser = argparse.ArgumentParser(description="Evaluate image quality by comparing to pseudo ground truth.")
    parser.add_argument("--path-evaluation-images", type=Path, help="Path to H5 file with images to evaluate.")
    parser.add_argument("--threshold-minimum", type=float, default=0.0, help="Min threshold used for remapping thermal "
        "images. Ignored if the thermal images are 8-bit.")
    parser.add_argument("--threshold-maximum", type=float, default=(2**16 - 1), help="Max threshold used for remapping "
        "thermal images. Ignored if the thermal images are 8-bit.")
    parser.add_argument("--name-camera", type=str, help="Camera name.")
    parser.add_argument("--undistort-evaluation", action='store_true', help="Whether to undistort the evaluation "
        "images (needed to perform evaluation with the raw thermal images).")
    parser.add_argument("--path-pseudo-ground-truth-images", type=Path, help="Path to H5 file with pseudo ground truth "
        "images.")
    parser.add_argument("--path-pseudo-ground-truth-poses", type=Path, help="Path to pose file for the pseudo ground "
        "truth image sequence. This is used to filter pseudo ground truth images.")
    parser.add_argument("--path-evaluation-poses", type=Path, help="Path to pose file for the evaluation sequence. "
        "This is used to determine the timestamps for evaluation and to filter pseudo ground truth images.")
    parser.add_argument("--path-calibration-results", type=Path, help="Path to Kalibr camchain YAML file.")
    parser.add_argument("--threshold-position", type=float, help="The position threshold (in meters) used to filter "
        "the pseudo ground truth images")
    parser.add_argument("--threshold-rotation", type=float, help="The rotation threshold (in degrees) used to filter "
        "the pseudo ground truth images")
    parser.add_argument('--use-gpu', action='store_true', help='If set, computations will be performed on a GPU.')
    parser.add_argument('--path-pickle-out-folder', type=Path, help="Path to the output folder for the results.")

    args = parser.parse_args()

    # Set the device
    assert not args.use_gpu or torch.cuda.is_available(), "CUDA is not available and is required to use a GPU."
    device = torch.device('cuda' if args.use_gpu else 'cpu')

    # Get undistortion maps if needed
    calibration_results = read_yaml(args.path_calibration_results)
    undistortion_map_1 = undistortion_map_2 = None
    if args.undistort_evaluation:
        _, undistortion_map_1, undistortion_map_2 = get_ideal_camera_matrix_and_undist_map(
            calibration_results, args.name_camera)

    # Read in timestamps from the evaluation sequence pose file
    pose_data_dict_evaluation = open_h5_pose_file(args.path_evaluation_poses)
    timestamps_evaluation = pose_data_dict_evaluation['timestamps']

    # Transform all poses to the thermal camera frame
    pose_data_dict_pseudo_ground_truth = open_h5_pose_file(args.path_pseudo_ground_truth_poses)
    poses_world_to_mono_left_pseudo_ground_truth = to_transformations(pose_data_dict_pseudo_ground_truth['positions'],
        pose_data_dict_pseudo_ground_truth['quaternions'])
    poses_world_to_mono_left_evaluation = to_transformations(pose_data_dict_evaluation['positions'],
        pose_data_dict_evaluation['quaternions'])
    transformation_mono_left_to_camera = get_transformation_from_calib(calibration_results, 'mono_left',
        args.name_camera)
    poses_world_to_camera_pseudo_ground_truth = transformation_mono_left_to_camera @ \
        poses_world_to_mono_left_pseudo_ground_truth
    poses_world_to_camera_evaluation = transformation_mono_left_to_camera @ poses_world_to_mono_left_evaluation

    # Open H5 image files
    image_data_dict_pseudo_ground_truth = open_h5_image_file(args.path_pseudo_ground_truth_images)
    image_data_dict_evaluation = open_h5_image_file(args.path_evaluation_images)

    # Loop through timestamps and process images
    evaluation_data = {}
    evaluation_data['type'] = 'lpips'
    evaluation_data['args'] = args
    evaluation_data['results'] = {}

    lpips_calculator = LearnedPerceptualImagePatchSimilarity(normalize=True).to(device)
    rotations_pseudo_ground_truth = Rotation.from_matrix(poses_world_to_camera_pseudo_ground_truth[:, :3, :3])
    positions_pseudo_ground_truth = poses_world_to_camera_pseudo_ground_truth[:, :3, 3]
    for timestamp in tqdm(timestamps_evaluation):
        # Check if the pose of the image to evaluate is close to any of the poses that exist in the sequence used to
        # generate the pseudo ground truth images
        # NOTE: this is to avoid comparing against inaccurate pseudo ground truth images that were generated from a
        # viewpoint far from those in the slow sequence training images
        index_pose_evaluation = np.argwhere(pose_data_dict_evaluation['timestamps'] == timestamp)[0][0]
        rotation_evaluation = Rotation.from_matrix(poses_world_to_camera_evaluation[index_pose_evaluation][:3, :3])
        position_evaluation = poses_world_to_camera_evaluation[index_pose_evaluation][:3, 3]

        distances_rotation = np.linalg.norm(
            (rotations_pseudo_ground_truth * rotation_evaluation.inv()).as_rotvec(degrees=True), axis=1)
        distances_position = np.linalg.norm(positions_pseudo_ground_truth - position_evaluation, axis=1)

        if not np.any((distances_position < args.threshold_position) * (distances_rotation < args.threshold_rotation)):
            evaluation_data['results'][timestamp] = {
                'min_translation': np.min(distances_position),
                'min_rotation': np.min(distances_rotation),
                'lpips': None}
            continue

        # Read in the pseudo ground truth and evaluation images
        image_pseudo_ground_truth = read_image_at_timestamp(timestamp, image_data_dict_pseudo_ground_truth,
            args.threshold_minimum, args.threshold_maximum)
        image_evaluation = read_image_at_timestamp(timestamp, image_data_dict_evaluation, args.threshold_minimum,
            args.threshold_maximum, undistortion_map_1=undistortion_map_1, undistortion_map_2=undistortion_map_2)

        # For the LPIPS calculator, the images need to have shape (N, 3, H, W) and be in the range [0, 1]
        image_pseudo_ground_truth = torch.from_numpy(image_pseudo_ground_truth.astype(np.float32)).to(device)
        image_pseudo_ground_truth = torch.unsqueeze(torch.unsqueeze(image_pseudo_ground_truth, 0), 0)
        image_pseudo_ground_truth = image_pseudo_ground_truth.repeat(1, 3, 1, 1) / 255.0

        image_evaluation = torch.from_numpy(image_evaluation.astype(np.float32)).to(device)
        image_evaluation = torch.unsqueeze(torch.unsqueeze(image_evaluation, 0), 0)
        image_evaluation = image_evaluation.repeat(1, 3, 1, 1) / 255.0

        # Compute the LPIPS metric and store the result
        lpips = lpips_calculator(image_evaluation, image_pseudo_ground_truth)
        evaluation_data['results'][timestamp] = {
            'min_translation': np.min(distances_position),
            'min_rotation': np.min(distances_rotation),
            'lpips': float(lpips)}

    # Write out the results
    path_pickle_out = args.path_pickle_out_folder / 'results_lpips_metric.pickle'
    pickle.dump(evaluation_data, open(path_pickle_out, 'wb'))
