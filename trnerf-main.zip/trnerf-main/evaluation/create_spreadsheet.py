import pickle
import argparse
import pandas as pd
import glob
import numpy as np
from pathlib import Path
from tqdm import tqdm

sequences = ['slow_outdoor', 'medium_outdoor', 'fast_outdoor', 'slow_indoor', 'medium_indoor', 'fast_indoor']

def get_camera(path):
    if 'left' in str(path):
        return 'left'
    elif 'right' in str(path):
        return 'right'
    else:
        return None

def get_sequence(path):
    for sequence in sequences:
        if sequence in str(path):
            return sequence
    return None

def get_method(path, camera, sequence):
    if camera is None or sequence is None:
        return None
    path = str(path)
    prefix = f'{camera}_{sequence}_'
    method = Path(path[path.find(prefix):]).parts[0][len(prefix):]
    return method

if __name__ == "__main__":
    # Process arguments
    parser = argparse.ArgumentParser(description="Compile computed metrics into a spreadsheet.")
    parser.add_argument('path_results_folder', type=str,
        help='Path to parent folder of multiple trial folders')

    args = parser.parse_args()

    # Determine result file paths
    paths_result_file = glob.glob(f'{args.path_results_folder}/**/*.pickle', recursive=True)

    # Compile results
    print('Processing result files...')
    results = {}
    for path_result_file in tqdm(paths_result_file):
        # Skip unexpected pickle files
        if not ('lpips' in path_result_file or 'detection' in path_result_file):
            continue

        # Read in the results
        evaluation_data = pickle.load(open(path_result_file, 'rb'))

        # Unpack the results
        path_trial_folder = Path(path_result_file).parent
        if not path_trial_folder in results:
            results[path_trial_folder] = {}

            # Attempt to infer the camera, sequence, and method names from the trial folder path
            camera = get_camera(path_trial_folder)
            sequence = get_sequence(path_trial_folder)
            method = get_method(path_trial_folder, camera, sequence)
            if camera and sequence and method:
                results[path_trial_folder]['camera'] = camera
                results[path_trial_folder]['sequence'] = sequence
                results[path_trial_folder]['method'] = method

        if evaluation_data['type'] == 'detection':
            timestamps = sorted(evaluation_data['results'].keys())
            n_imgs_detection = n_corners_reproj = n_detected = 0
            reprojection_errors = []
            for timestamp in timestamps:
                result = evaluation_data['results'][timestamp]
                detection_data = result['detection_data']
                if not detection_data is None and len(detection_data['corners_thermal_image_frame_reprojected']) != 0:
                    n_imgs_detection += 1
                    n_corners_reproj += len(detection_data['corners_thermal_image_frame_reprojected'])
                    n_detected += len(detection_data['ids_corner_common'])
                    reprojection_errors += detection_data['reprojection_errors']
            percent_detected = (n_detected / n_corners_reproj) * 100

            results[path_trial_folder]['n_imgs_detection'] = n_imgs_detection
            results[path_trial_folder]['n_corners_reproj'] = n_corners_reproj
            results[path_trial_folder]['percent_detected'] = percent_detected
            results[path_trial_folder]['reprojection_error'] = None if len(reprojection_errors) == 0 else \
                np.mean(reprojection_errors)

        elif evaluation_data['type'] == 'lpips':
            timestamps = sorted(evaluation_data['results'].keys())
            n_imgs_lpips = 0
            lpips_list = []
            for timestamp in timestamps:
                result = evaluation_data['results'][timestamp]
                if not result['lpips'] is None:
                    n_imgs_lpips += 1
                    lpips_list.append(result['lpips'])

            results[path_trial_folder]['n_imgs_lpips'] = n_imgs_lpips
            results[path_trial_folder]['lpips'] = None if len(lpips_list) == 0 else np.mean(lpips_list)

    # Write results out to a spreadsheet
    column_names = ['path_trial_folder']
    for path_trial_folder in results:
        for column_name in results[path_trial_folder]:
            if not column_name in column_names:
                column_names.append(column_name)
    spreadsheet_dict = {column_name:[] for column_name in column_names}
    for path_trial_folder in results:
        spreadsheet_dict['path_trial_folder'].append(path_trial_folder)
        for column_name in column_names[1:]:
            if column_name in results[path_trial_folder]:
                spreadsheet_dict[column_name].append(results[path_trial_folder][column_name])
            else:
                spreadsheet_dict[column_name].append(None)
    path_spreadsheet = f'{args.path_results_folder}/results.xlsx'
    with pd.ExcelWriter(path_spreadsheet) as writer:
        pd.DataFrame(spreadsheet_dict).to_excel(writer, sheet_name='Results')
