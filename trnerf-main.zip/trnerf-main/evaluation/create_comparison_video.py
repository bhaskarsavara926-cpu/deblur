import cv2
import numpy as np
import argparse
from pathlib import Path
import pickle
from tqdm import tqdm

from trnerf_utils import read_yaml, open_h5_image_file, get_ideal_camera_matrix_and_undist_map, read_image_at_timestamp

def draw_detection(image, corners_detected, detection_data=None, is_mono=False):
    # Visualize reprojection data if available
    if not detection_data is None:
        # Draw ignored reprojected grid corners in green
        corners_reprojected_ignored = detection_data['corners_thermal_image_frame_reprojected_ignored']
        for id in corners_reprojected_ignored:
            image = cv2.circle(image,
                (int(corners_reprojected_ignored[id][0]), int(corners_reprojected_ignored[id][1])), 4, (0, 128, 0), -1)

        corners_reprojected = detection_data['corners_thermal_image_frame_reprojected']
        if len(corners_reprojected) != 0:
            # Draw utilized reprojected grid corners in blue
            for id in corners_reprojected:
                image = cv2.circle(image, (int(corners_reprojected[id][0]), int(corners_reprojected[id][1])), 4,
                    (255, 0, 0), -1)

            # Annotate with the percent of utilized grid corners detected
            cv2.putText(image, "Percent detected: {:.2f}%".format(detection_data['percent_detected']),
                (20, 40), cv2.FONT_HERSHEY_SIMPLEX, fontScale=0.75, color=(0, 0, 255), thickness=2)

            # Annotate with the reprojection error mean if any utilized grid corners were detected
            if len(detection_data['reprojection_errors']) != 0:
                reprojection_error_mean = np.mean(detection_data['reprojection_errors'])
                cv2.putText(image, "Mean Reproj. Error: {:.2f} pix".format(reprojection_error_mean), (20, 80),
                    cv2.FONT_HERSHEY_SIMPLEX, fontScale=0.75, color=(0, 0, 255), thickness=2)

    # Draw the detected grid corners in red
    pointsize = 8 if is_mono else 4
    for id in corners_detected:
        image = cv2.circle(image, (int(corners_detected[id][0]), int(corners_detected[id][1])), pointsize,
            (0, 0, 255), -1)

    return image

if __name__ == "__main__":
    # Process arguments
    parser = argparse.ArgumentParser(description='Creating a video comparing thermal images from the same sequence.')
    parser.add_argument('--paths', nargs='+', type=Path, help='Paths to either trial folders or H5 image files. If '
        'trial folders, the folders must contain both result files, results_detection_metric.pickle and '
        'results_lpips_metric.pickle, that will be used to determine the evaluation and pseudo ground truth images to '
        'include in the video. If H5 files, the video will be directly formed from the files.')
    parser.add_argument('--threshold-minimum', type=float, default=None, help='Min threshold used for remapping '
        'thermal images. This argument is optional if the --paths are to trial folders. In that case the threshold '
        'can be read in from the results files (or overwritten with this argument). If the --paths are to H5 files '
        'this argument is required.')
    parser.add_argument('--threshold-maximum', type=float, default=None, help='Max threshold used for remapping '
        'thermal images. This argument is optional if the --paths are to trial folders. In that case the threshold '
        'can be read in from the results files (or overwritten with this argument). If the --paths are to H5 files '
        'this argument is required.')
    parser.add_argument('--method-list', nargs='+', type=str, default=[], help='An optional list of strings denoting '
        'the method names for each item in --paths. If provided, these method names will be used to annotate the '
        'videos. In method names with multiple words, the words should be separated with hyphens, which will be '
        'removed in the annotation.')
    parser.add_argument('--include-pseudo-gt', action='store_true', help='Whether to include pseudo ground truth '
        'images in the output video. Ignored if the --paths are H5 files.')
    parser.add_argument('--annotate-results', action='store_true', help='Whether to annotate the images with the '
        'frame-by-frame detection and LPIPS results. Ignored if the --paths are H5 files.')
    parser.add_argument('--include-monochrome', action='store_true', help='Whether to include the left monochrome '
        'images used in computing the detection metric in the output video. Ignored if the --paths are H5 files.')
    parser.add_argument("--include-lpips-only", action='store_true', help='Include only the images used to compute '
        'the LPIPS metric. If enabled, the detection metric annotations will not be included. Ignored if the --paths '
        'are H5 files.')
    parser.add_argument("--include-detection-only", action='store_true', help='Include only the images used to compute '
        'the detection metric. If enabled, the LPIPS metric annotations will not be included. Ignored if the --paths '
        'are H5 files.')
    parser.add_argument('--grid-shape', nargs='+', type=int, help='The 2D grid shape for tiling the output videos '
        'together.')
    parser.add_argument("--path-output-video", type=Path, help='The path to the output .mp4 video.')
    parser.add_argument("--playback-rate", type=float, default=1.0, help='Playback rate in the video.')

    args_video = parser.parse_args()

    is_h5 = ('.h5' in str(args_video.paths[0]))
    is_consistent = True
    for path in args_video.paths[1:]:
        is_consistent = is_consistent and (('.h5' in str(path)) == is_h5)
    assert is_consistent, 'The paths need to be either all trial folders or all H5 image files'

    if is_h5:
        assert (not args_video.threshold_minimum is None) and (not args_video.threshold_maximum is None), \
            'If the input paths are H5 image files, the threshold arguments are required'
    assert len(args_video.method_list) == 0 or len(args_video.method_list) == len(args_video.paths), \
        'If provided, the method list should be the same length as the paths list'
    assert not (args_video.include_lpips_only and args_video.include_detection_only), \
        'Cannot set both include_lpips_only and include_detection_only'
    assert len(args_video.grid_shape) == 2, 'The grid shape and must be 2D.'

    n_tiles = len(args_video.paths)
    n_tiles += 1 if (not is_h5) and args_video.include_pseudo_gt else 0
    n_tiles += 1 if (not is_h5) and args_video.include_monochrome else 0
    assert n_tiles == args_video.grid_shape[0] * args_video.grid_shape[1], \
        f'The grid shape is incompatible with the required number of tiles ({n_tiles}).'

    image_data_dict_mono_left = None
    image_data_dict_pseudo_gt = None
    image_data_dict_thermal_list = []
    if not is_h5:
        # Load the evaluation results
        eval_data_detection_list = []
        eval_data_lpips_list = []
        for path in args_video.paths:
            eval_data_detection_list.append(pickle.load(open(path / 'results_detection_metric.pickle', 'rb')))
            eval_data_lpips_list.append(pickle.load(open(path / 'results_lpips_metric.pickle', 'rb')))

        # Confirm that the evaluation results are compatible
        args_eval = vars(eval_data_detection_list[0]['args'])
        for eval_data in eval_data_detection_list[1:]:
            args_i = vars(eval_data['args'])
            assert \
                args_eval['threshold_minimum'] == args_i['threshold_minimum'] and \
                args_eval['threshold_maximum'] == args_i['threshold_maximum'] and \
                args_eval['name_thermal'] == args_i['name_thermal'] and \
                args_eval['path_mono_left'] == args_i['path_mono_left'] and \
                args_eval['path_poses'] == args_i['path_poses'] and \
                args_eval['path_calibration_results'] == args_i['path_calibration_results'] and \
                args_eval['path_grid_config'] == args_i['path_grid_config'] and \
                args_eval['ids_tag_row_ignore'] == args_i['ids_tag_row_ignore'], \
                'At least one of the evaluation results are incompatible for comparison due to an argument that ' \
                'varies between them'
        for eval_data in eval_data_lpips_list:
            args_i = vars(eval_data['args'])
            assert \
                args_eval['threshold_minimum'] == args_i['threshold_minimum'] and \
                args_eval['threshold_maximum'] == args_i['threshold_maximum'] and \
                args_eval['name_thermal'] == args_i['name_camera'] and \
                args_eval['path_poses'] == args_i['path_evaluation_poses'] and \
                args_eval['path_calibration_results'] == args_i['path_calibration_results'], \
                'At least one of the evaluation results are incompatible for comparison due to an argument that ' \
                'varies between them'
        args_eval.update(vars(eval_data_lpips_list[0]['args']))
        for eval_data in eval_data_lpips_list[1:]:
            args_i = vars(eval_data['args'])
            assert \
                args_eval['threshold_minimum'] == args_i['threshold_minimum'] and \
                args_eval['threshold_maximum'] == args_i['threshold_maximum'] and \
                args_eval['name_camera'] == args_i['name_camera'] and \
                args_eval['path_pseudo_ground_truth_images'] == args_i['path_pseudo_ground_truth_images'] and \
                args_eval['path_pseudo_ground_truth_poses'] == args_i['path_pseudo_ground_truth_poses'] and \
                args_eval['path_evaluation_poses'] == args_i['path_evaluation_poses'] and \
                args_eval['path_calibration_results'] == args_i['path_calibration_results'] and \
                args_eval['threshold_position'] == args_i['threshold_position'] and \
                args_eval['threshold_rotation'] == args_i['threshold_rotation'], \
                'At least one of the evaluation results are incompatible for comparison due to an argument that ' \
                'varies between them'

        # Get undistortion maps
        _, undistortion_map_1, undistortion_map_2 = get_ideal_camera_matrix_and_undist_map(
            read_yaml(args_eval['path_calibration_results']), args_eval['name_camera'])

        # Set the thresholds
        threshold_minimum = args_video.threshold_minimum if args_video.threshold_minimum else \
            args_eval['threshold_minimum']
        threshold_maximum = args_video.threshold_maximum if args_video.threshold_maximum else \
            args_eval['threshold_maximum']

        # Open H5 image files
        if args_video.include_monochrome:
            image_data_dict_mono_left = open_h5_image_file(args_eval['path_mono_left'])
        if args_video.include_pseudo_gt:
            image_data_dict_pseudo_gt = open_h5_image_file(args_eval['path_pseudo_ground_truth_images'])
        for eval_data_detection in eval_data_detection_list:
            image_data_dict_thermal_list.append(open_h5_image_file(eval_data_detection['args'].path_thermal_images))

    else:
        # Set the thresholds
        threshold_minimum = args_video.threshold_minimum
        threshold_maximum = args_video.threshold_maximum

        # Open H5 image files
        for path in args_video.paths:
            image_data_dict_thermal_list.append(open_h5_image_file(path))

    # Identify common timestamps
    timestamps_common = image_data_dict_thermal_list[0]['timestamps']
    for image_data_dict_thermal in image_data_dict_thermal_list:
        timestamps_common = np.intersect1d(image_data_dict_thermal['timestamps'], timestamps_common)

    # Loop through images and write them out to the video
    thermal_image_shape = image_data_dict_thermal_list[0]['images'][0].shape
    video_writer = cv2.VideoWriter(str(args_video.path_output_video), cv2.VideoWriter_fourcc(*'mp4v'),
        int(60 * args_video.playback_rate), (thermal_image_shape[1] * args_video.grid_shape[1],
        thermal_image_shape[0] * args_video.grid_shape[0]))

    print('Writing video...')
    for timestamp in tqdm(timestamps_common):
        # Determine if the image contributed to particular metrics and potentially skip those that did not
        is_included_detection = False
        is_included_lpips = False
        if not is_h5:
            detection_data_0 = eval_data_detection_list[0]['results'][timestamp]['detection_data']
            is_included_detection = not detection_data_0 is None and \
                len(detection_data_0['corners_thermal_image_frame_reprojected']) != 0
            is_included_lpips = not eval_data_lpips_list[0]['results'][timestamp]['lpips'] is None
            if args_video.include_detection_only and not is_included_detection:
                continue
            if args_video.include_lpips_only and not is_included_lpips:
                continue

        # Read in and annotate the monochrome image if enabled
        image_list = []
        if not image_data_dict_mono_left is None:
            image_mono_left = read_image_at_timestamp(timestamp, image_data_dict_mono_left)
            image_mono_left = image_mono_left[:, :, None].repeat(3, axis=2)
            if is_included_detection and args_video.annotate_results and not args_video.include_lpips_only:
                image_mono_left = draw_detection(image_mono_left,
                    eval_data_detection_list[0]['results'][timestamp]['corners_mono_left'], is_mono=True)

            # Resize and add borders to the monochrome image so its resolution matches that of the thermal images
            ratio_width = thermal_image_shape[1] / image_mono_left.shape[1]
            image_mono_left = cv2.resize(image_mono_left, (0, 0), fx=ratio_width, fy=ratio_width)
            image_mono_left_with_borders = np.zeros((thermal_image_shape[0], thermal_image_shape[1], 3), dtype=np.uint8)
            top_row = int((thermal_image_shape[0] - image_mono_left.shape[0]) / 2)
            image_mono_left_with_borders[top_row:top_row + image_mono_left.shape[0], :] = image_mono_left

            if args_video.method_list:
                cv2.putText(image_mono_left_with_borders, 'Monochrome', (20, 490), cv2.FONT_HERSHEY_SIMPLEX,
                    fontScale=0.75, color=(0, 0, 255), thickness=2)

            image_list.append(image_mono_left_with_borders)

        # Read in amd annotate the pseudo ground truth image if enabled
        if not image_data_dict_pseudo_gt is None:
            image_pseudo_gt = read_image_at_timestamp(timestamp, image_data_dict_pseudo_gt, threshold_minimum,
                threshold_maximum)
            image_pseudo_gt = image_pseudo_gt[:, :, None].repeat(3, axis=2)
            if args_video.method_list:
                cv2.putText(image_pseudo_gt, 'Pseudo Ground Truth', (20, 490), cv2.FONT_HERSHEY_SIMPLEX,
                    fontScale=0.75, color=(0, 0, 255), thickness=2)

            image_list.append(image_pseudo_gt)

        # Collect all evaluation images to include in the video
        for i, image_data_dict_thermal in enumerate(image_data_dict_thermal_list):
            # Read in the thermal evaluation image, applying undistortion if it was during evaluation
            if not is_h5 and eval_data_detection_list[i]['args'].undistort_thermal:
                image_eval = read_image_at_timestamp(timestamp, image_data_dict_thermal_list[i],
                    threshold_minimum, threshold_maximum, undistortion_map_1=undistortion_map_1,
                    undistortion_map_2=undistortion_map_2)
            else:
                image_eval = read_image_at_timestamp(timestamp, image_data_dict_thermal_list[i], threshold_minimum,
                    threshold_maximum)
            image_eval = image_eval[:, :, None].repeat(3, axis=2)

            # Apply enabled annotations
            if is_included_detection and args_video.annotate_results and not args_video.include_lpips_only:
                image_eval = draw_detection(image_eval,
                    eval_data_detection_list[i]['results'][timestamp]['corners_thermal'],
                    eval_data_detection_list[i]['results'][timestamp]['detection_data'])
            if is_included_lpips and args_video.annotate_results and not args_video.include_detection_only:
                lpips = eval_data_lpips_list[i]['results'][timestamp]['lpips']
                cv2.putText(image_eval, "LPIPS: {:.3f}".format(lpips), (470, 40), cv2.FONT_HERSHEY_SIMPLEX,
                    fontScale=0.75, color=(0, 0, 255), thickness=2)
            if args_video.method_list:
                method_name = args_video.method_list[i]
                cv2.putText(image_eval, method_name.replace('-', ' '), (20, 490), cv2.FONT_HERSHEY_SIMPLEX,
                    fontScale=0.75, color=(0, 0, 255), thickness=2)

            image_list.append(image_eval)

        # Create the combined image and write it to the video
        n_rows = args_video.grid_shape[0]
        n_cols = args_video.grid_shape[1]
        image_row_list = []
        for i in range(n_rows):
            image_row_list.append(cv2.hconcat(image_list[i * n_cols:(i + 1) * n_cols]))
        image_full = cv2.vconcat(image_row_list)
        video_writer.write(image_full)

    video_writer.release()
