import yaml
import h5py
from pathlib import Path
import numpy as np
from scipy.spatial.transform import Rotation
import os
import cv2

def create_output_directory(path):
    if not os.path.exists(path):
        os.makedirs(path)

def read_yaml(path_yaml_file):
    with open(path_yaml_file, 'r') as file_object:
        info = yaml.safe_load(file_object)
    return info

def open_h5_image_file(path_h5_file):
    h5_file = h5py.File(path_h5_file, 'r')

    supported_image_group_names = ['image_raw', 'image_rendered']
    images_found = False
    for image_group_name in supported_image_group_names:
        if image_group_name in h5_file.keys():
            images_found = True
            try:
                group_image = h5_file[image_group_name]
            except:
                print(f"Failed to open '{image_group_name}' group in H5 file: {h5_file.filename}")
                exit()
            break
    if not images_found:
        print(f'H5 file does not contain any of the supported image group names: {supported_image_group_names}')
        exit()

    images = group_image['images']
    timestamps = group_image['timestamps'][:]
    encoding = group_image.attrs['encoding']
    name = Path(path_h5_file).parts[-1][:-3]

    image_data_dict = {'name': name, 'images': images, 'timestamps': timestamps, 'encoding': encoding}

    return image_data_dict

def read_image_at_timestamp(timestamp, image_data_dict, threshold_minimum=0.0, threshold_maximum=(2**16 - 1),
    convert_to_8bit=True, gain=None, offset=None, undistortion_map_1=None, undistortion_map_2=None):
    # Determine the image index from the timestamp and read in the image
    index_image = np.argwhere(image_data_dict['timestamps'] == timestamp)[0][0]
    image = image_data_dict['images'][index_image]

    # Apply the pixelwise gains and offsets, if they were provided
    if not (gain is None) and not (offset is None):
        image = (image - offset) / gain

    # Apply the undistortion maps, if they were provided
    if not (undistortion_map_1 is None) and not (undistortion_map_2 is None):
        image = cv2.remap(image, undistortion_map_1, undistortion_map_2, cv2.INTER_LINEAR)

    # Rescale 16 bit images
    if image_data_dict['encoding'] == 'mono16':
        # Truncate the image between the min and max bounds and map the values to the range [0, 1]
        image[image < threshold_minimum] = threshold_minimum
        image[image > threshold_maximum] = threshold_maximum
        image = (image.astype(np.float32) - threshold_minimum) / (threshold_maximum - threshold_minimum)

        # Convert the image to 8-bit, if enabled
        if convert_to_8bit:
            image = np.round(image * 255.0).astype(np.uint8)

    return image

def open_h5_pose_file(path_h5_file):
    h5_file = h5py.File(path_h5_file, 'r')
    try:
        group_poses = h5_file['poses_mono_left']
    except:
        print(f"Failed to open '/poses_mono_left' group in H5 file: {h5_file.filename}")
        exit()

    positions = group_poses['positions'][:]
    quaternions = group_poses['quaternions'][:]
    timestamps = group_poses['timestamps'][:]

    pose_data_dict = {'positions': positions, 'quaternions': quaternions, 'timestamps': timestamps}

    return pose_data_dict

def to_transformations(positions, quaternions):
    rotation_matrices = Rotation.from_quat(quaternions).as_matrix()
    transformations = []
    for position, rotation_matrix in zip(positions, rotation_matrices):
        transformation = np.eye(4)
        transformation[:3, :3] = rotation_matrix
        transformation[:3, 3] = position
        transformations.append(transformation)

    return np.asarray(transformations)

def invert_transformation_matrix(transformation_matrix):
    transformation_matrix_inverse = np.eye(4)
    transformation_matrix_inverse[0:3, 0:3] = transformation_matrix[0:3, 0:3].T
    transformation_matrix_inverse[0:3, 3] = -transformation_matrix_inverse[0:3, 0:3] @ transformation_matrix[0:3, 3]

    return transformation_matrix_inverse

def get_camera_index(calibration_results, camera_name):
    for key in calibration_results:
        if camera_name in calibration_results[key]['rostopic'].replace('/', '_'):
            return int(key.replace('cam', ''))
    print(f'The camera {camera_name} was not found in the calibration file')
    exit()

def get_transformation_from_calib(calibration_results, source_camera_name, target_camera_name):
    # Identify source and target camera indices in the calibration results
    index_source_camera = get_camera_index(calibration_results, source_camera_name)
    index_target_camera = get_camera_index(calibration_results, target_camera_name)

    # Get the transformation matrix from the source camera to the target camera
    transformation_source_to_target = np.eye(4)
    for index_camera in range(np.min([index_source_camera, index_target_camera]) + 1,
        np.max([index_source_camera, index_target_camera]) + 1):
        transformation_prev_to_current = np.asarray(calibration_results['cam' + str(index_camera)]['T_cn_cnm1'])
        transformation_source_to_target = transformation_prev_to_current @ transformation_source_to_target
    if index_target_camera < index_source_camera:
        transformation_source_to_target = invert_transformation_matrix(transformation_source_to_target)

    return transformation_source_to_target

def get_ideal_camera_matrix_and_undist_map(calibration_results, name_camera):
    # Unpack the calibration results
    index_camera = get_camera_index(calibration_results, name_camera)
    calibration_result = calibration_results['cam' + str(index_camera)]
    intrinsics = calibration_result['intrinsics']
    camera_matrix = np.eye(3)
    camera_matrix[0, 0] = intrinsics[0]
    camera_matrix[1, 1] = intrinsics[1]
    camera_matrix[0, 2] = intrinsics[2]
    camera_matrix[1, 2] = intrinsics[3]
    distortion_coefficients = np.array(calibration_result['distortion_coeffs'])
    resolution = calibration_result['resolution']

    # Compute the ideal camera matrix
    # Using alpha = 0 to ensure no invalid pixels
    camera_matrix_ideal, _ = cv2.getOptimalNewCameraMatrix(camera_matrix, distortion_coefficients, tuple(resolution),
        alpha=0)

    # Compute the undistortion maps
    # Using CV_32FC1 for slower but more accurate remapping, see OpenCV's documentation of convertMaps()
    undistortion_map_1, undistortion_map_2 = cv2.initUndistortRectifyMap(camera_matrix,
        distortion_coefficients, np.eye(3), camera_matrix_ideal, tuple(resolution), cv2.CV_32FC1)

    return camera_matrix_ideal, undistortion_map_1, undistortion_map_2
