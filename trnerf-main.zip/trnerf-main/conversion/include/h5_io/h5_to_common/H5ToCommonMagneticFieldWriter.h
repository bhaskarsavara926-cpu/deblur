#ifndef H5TOCOMMONMAGNETICFIELDWRITER_H
#define H5TOCOMMONMAGNETICFIELDWRITER_H

#include "h5_io/h5_to_common/H5ToCommonWriter.h"

class H5ToCommonMagneticFieldWriter : public H5ToCommonWriter
{
public:
    H5ToCommonMagneticFieldWriter(H5::Group& group);

    /************************ public member functions ************************/

    void writeH5TopicGroup(const std::string path_output);
};

#endif //H5TOCOMMONMAGNETICFIELDWRITER_H