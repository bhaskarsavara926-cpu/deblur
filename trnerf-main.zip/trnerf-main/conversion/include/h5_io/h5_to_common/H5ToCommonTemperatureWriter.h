#ifndef H5TOCOMMONTEMPERATUREWRITER_H
#define H5TOCOMMONTEMPERATUREWRITER_H

#include "h5_io/h5_to_common/H5ToCommonWriter.h"

class H5ToCommonTemperatureWriter : public H5ToCommonWriter
{
public:
    H5ToCommonTemperatureWriter(H5::Group& group);

    /************************ public member functions ************************/

    void writeH5TopicGroup(const std::string path_output);
};

#endif //H5TOCOMMONTEMPERATUREWRITER_H