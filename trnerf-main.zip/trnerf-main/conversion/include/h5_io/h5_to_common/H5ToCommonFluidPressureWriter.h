#ifndef H5TOCOMMONFLUIDPRESSUREWRITER_H
#define H5TOCOMMONFLUIDPRESSUREWRITER_H

#include "h5_io/h5_to_common/H5ToCommonWriter.h"

class H5ToCommonFluidPressureWriter : public H5ToCommonWriter
{
public:
    H5ToCommonFluidPressureWriter(H5::Group& group);

    /************************ public member functions ************************/

    void writeH5TopicGroup(const std::string path_output);
};

#endif //H5TOCOMMONFLUIDPRESSUREWRITER_H