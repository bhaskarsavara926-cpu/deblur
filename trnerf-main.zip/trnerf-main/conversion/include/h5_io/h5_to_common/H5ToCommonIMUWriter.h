#ifndef H5TOCOMMONIMUWRITER_H
#define H5TOCOMMONIMUWRITER_H

#include "h5_io/h5_to_common/H5ToCommonWriter.h"

class H5ToCommonIMUWriter : public H5ToCommonWriter
{
public:
    H5ToCommonIMUWriter(H5::Group& group);

    /************************ public member functions ************************/

    void writeH5TopicGroup(const std::string path_output);
};

#endif //H5TOCOMMONIMUWRITER_H