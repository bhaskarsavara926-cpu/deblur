#ifndef H5TOROSTEMPERATUREWRITER_H
#define H5TOROSTEMPERATUREWRITER_H

#include "h5_io/h5_to_ros/H5ToRosMessageWriter.h"

class H5ToRosTemperatureWriter : public H5ToRosMessageWriter
{
public:
    H5ToRosTemperatureWriter(H5::Group& group);

    /************************ public member functions ************************/

    void writeH5TopicGroup(
        const std::string topic,
        rosbag::Bag& bag);
};

#endif //H5TOROSTEMPERATUREWRITER_H