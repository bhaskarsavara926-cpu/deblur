#ifndef H5TOROSMAGNETICFIELDWRITER_H
#define H5TOROSMAGNETICFIELDWRITER_H

#include "h5_io/h5_to_ros/H5ToRosMessageWriter.h"

class H5ToRosMagneticFieldWriter : public H5ToRosMessageWriter
{
public:
    H5ToRosMagneticFieldWriter(H5::Group& group);

    /************************ public member functions ************************/

    void writeH5TopicGroup(
        const std::string topic,
        rosbag::Bag& bag);
};

#endif //H5TOROSMAGNETICFIELDWRITER_H