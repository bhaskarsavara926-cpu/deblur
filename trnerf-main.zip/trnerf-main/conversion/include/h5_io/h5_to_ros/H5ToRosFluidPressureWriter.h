#ifndef H5TOROSFLUIDPRESSUREWRITER_H
#define H5TOROSFLUIDPRESSUREWRITER_H

#include "h5_io/h5_to_ros/H5ToRosMessageWriter.h"

class H5ToRosFluidPressureWriter : public H5ToRosMessageWriter
{
public:
    H5ToRosFluidPressureWriter(H5::Group& group);

    /************************ public member functions ************************/

    void writeH5TopicGroup(
        const std::string topic,
        rosbag::Bag& bag);
};

#endif //H5TOROSFLUIDPRESSUREWRITER_H