#ifndef H5TOROSIMUWRITER_H
#define H5TOROSIMUWRITER_H

#include "h5_io/h5_to_ros/H5ToRosMessageWriter.h"

class H5ToRosIMUWriter : public H5ToRosMessageWriter
{
public:
    H5ToRosIMUWriter(H5::Group& group);

    /************************ public member functions ************************/

    void writeH5TopicGroup(
        const std::string topic,
        rosbag::Bag& bag);
};

#endif //H5TOROSIMUWRITER_H