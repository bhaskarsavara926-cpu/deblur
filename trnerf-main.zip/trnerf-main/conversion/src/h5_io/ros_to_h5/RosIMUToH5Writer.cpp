#include "h5_io/ros_to_h5/RosIMUToH5Writer.h"

#include <cassert>
#include <iostream>

#include <rosbag/view.h>
#include <sensor_msgs/Imu.h>

RosIMUToH5Writer::RosIMUToH5Writer(
    const int chunk_length,
    const int chunk_cache_size,
    const bool shuffle_enable,
    const std::shared_ptr<const CompressionMethod> compression_method,
    const std::shared_ptr<H5::H5File> h5_file,
    const uint64_t time_shift_camera_to_imu)
    :   RosMessageToH5Writer(
            chunk_length,
            chunk_cache_size,
            shuffle_enable,
            compression_method,
            h5_file),
        time_shift_camera_to_imu_(time_shift_camera_to_imu)
{}

void RosIMUToH5Writer::writeRosbagTopicView(
    const std::string path_group,
    rosbag::View& view_topic)
{
    std::vector<const rosbag::ConnectionInfo*> connections = view_topic.getConnections();

    // Check that the view only has a single topic
    if (connections.size() > 1)
    {
        std::cout << "writeRosbagTopicView only supports views of a single topic\n";
        assert(false);
    }

    // Check the message type
    if (connections[0]->datatype != "sensor_msgs/Imu")
    {
        std::cout << "RosIMUToH5Writer only supports sensor_msgs/Imu messages\n";
        assert(false);
    }

    // Add the group, if it does not already exist
    addGroup(path_group);

    // Write meta information as attributes to the group
    writeAttributeToObject(path_group, "ros_message_type", connections[0]->datatype);

    // Create datasets, with units and descriptors written as attributes
    size_t n_messages = view_topic.size();

    std::string path_timestamp_dataset = path_group + "/timestamps";
    addDataset<uint64_t>(path_timestamp_dataset, n_messages);
    writeAttributeToObject<std::string>(path_timestamp_dataset, "units", "nanoseconds");

    std::string path_quaternions_dataset = path_group + "/quaternions";
    std::vector<hsize_t> dimensions_quaternion_data{4};
    addDataset<double>(path_quaternions_dataset, n_messages, dimensions_quaternion_data);
    writeAttributeToObject<std::string>(path_quaternions_dataset, "column order", "x, y, z, w");
    writeAttributeToObject<std::string>(path_quaternions_dataset, "parent_frame", "NED");
    writeAttributeToObject<std::string>(path_quaternions_dataset, "child_frame", "IMU");

    std::string path_angular_velocities_dataset = path_group + "/angular_velocities";
    std::vector<hsize_t> dimensions_angular_velocity_data{3};
    addDataset<double>(path_angular_velocities_dataset, n_messages, dimensions_angular_velocity_data);
    writeAttributeToObject<std::string>(path_angular_velocities_dataset, "units", "radians/second");
    writeAttributeToObject<std::string>(path_angular_velocities_dataset, "column order", "x, y, z");
    writeAttributeToObject<std::string>(path_angular_velocities_dataset, "frame", "IMU");

    std::string path_linear_accelerations_dataset = path_group + "/linear_accelerations";
    std::vector<hsize_t> dimensions_linear_acceleration_data{3};
    addDataset<double>(path_linear_accelerations_dataset, n_messages, dimensions_linear_acceleration_data);
    writeAttributeToObject<std::string>(path_linear_accelerations_dataset, "units", "meters/second^2");
    writeAttributeToObject<std::string>(path_linear_accelerations_dataset, "column order", "x, y, z");
    writeAttributeToObject<std::string>(path_linear_accelerations_dataset, "frame", "IMU");

    size_t message_count = 0;
    std::vector<uint64_t> timestamps_to_write;
    std::vector<double> quaternions_to_write;
    std::vector<double> angular_velocities_to_write;
    std::vector<double> linear_accelerations_to_write;
    for (rosbag::MessageInstance const message_instance : view_topic)
    {
        sensor_msgs::Imu::Ptr message_imu = message_instance.instantiate<sensor_msgs::Imu>();

        timestamps_to_write.push_back(message_imu->header.stamp.toNSec() - time_shift_camera_to_imu_);
        quaternions_to_write.push_back(message_imu->orientation.x);
        quaternions_to_write.push_back(message_imu->orientation.y);
        quaternions_to_write.push_back(message_imu->orientation.z);
        quaternions_to_write.push_back(message_imu->orientation.w);
        angular_velocities_to_write.push_back(message_imu->angular_velocity.x);
        angular_velocities_to_write.push_back(message_imu->angular_velocity.y);
        angular_velocities_to_write.push_back(message_imu->angular_velocity.z);
        linear_accelerations_to_write.push_back(message_imu->linear_acceleration.x);
        linear_accelerations_to_write.push_back(message_imu->linear_acceleration.y);
        linear_accelerations_to_write.push_back(message_imu->linear_acceleration.z);
        if (timestamps_to_write.size() == chunk_length_)
        {
            size_t index_message = message_count - chunk_length_ + 1;
            writeDataToDataset(path_timestamp_dataset, timestamps_to_write, index_message, chunk_length_);
            writeDataToDataset(path_quaternions_dataset, quaternions_to_write, index_message, chunk_length_);
            writeDataToDataset(path_angular_velocities_dataset, angular_velocities_to_write, index_message,
                chunk_length_);
            writeDataToDataset(path_linear_accelerations_dataset, linear_accelerations_to_write, index_message,
                chunk_length_);
            timestamps_to_write.clear();
            quaternions_to_write.clear();
            angular_velocities_to_write.clear();
            linear_accelerations_to_write.clear();
        }

        message_count++;

        if (message_count % chunk_length_ == 0)
        {
            std::cout << "\33[2K\rPercent completion: " << 100.0 * message_count / n_messages << std::flush;
        }
    }

    // Write any remaining messages that didn't fit perfectly in a chunk
    if (timestamps_to_write.size() > 0)
    {
        size_t index_message = message_count - timestamps_to_write.size();
        writeDataToDataset(path_timestamp_dataset, timestamps_to_write, index_message, timestamps_to_write.size());
        writeDataToDataset(path_quaternions_dataset, quaternions_to_write, index_message, timestamps_to_write.size());
        writeDataToDataset(path_angular_velocities_dataset, angular_velocities_to_write, index_message,
            timestamps_to_write.size());
        writeDataToDataset(path_linear_accelerations_dataset, linear_accelerations_to_write, index_message,
            timestamps_to_write.size());
    }

    std::cout << "\33[2K\rPercent completion: " << 100.0 << std::flush << std::endl;
}