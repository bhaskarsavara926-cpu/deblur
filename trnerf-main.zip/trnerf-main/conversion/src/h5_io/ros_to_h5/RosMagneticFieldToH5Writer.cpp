#include "h5_io/ros_to_h5/RosMagneticFieldToH5Writer.h"

#include <cassert>
#include <iostream>

#include <rosbag/view.h>
#include <sensor_msgs/MagneticField.h>

RosMagneticFieldToH5Writer::RosMagneticFieldToH5Writer(
    const int chunk_length,
    const int chunk_cache_size,
    const bool shuffle_enable,
    const std::shared_ptr<const CompressionMethod> compression_method,
    const std::shared_ptr<H5::H5File> h5_file,
    const uint64_t time_shift_camera_to_imu)
    :   RosMessageToH5Writer(
            chunk_length,
            chunk_cache_size,
            shuffle_enable,
            compression_method,
            h5_file),
        time_shift_camera_to_imu_(time_shift_camera_to_imu)
{}

void RosMagneticFieldToH5Writer::writeRosbagTopicView(
    const std::string path_group,
    rosbag::View& view_topic)
{
    std::vector<const rosbag::ConnectionInfo*> connections = view_topic.getConnections();

    // Check that the view only has a single topic
    if (connections.size() > 1)
    {
        std::cout << "writeRosbagTopicView only supports views of a single topic\n";
        assert(false);
    }

    // Check the message type
    if (connections[0]->datatype != "sensor_msgs/MagneticField")
    {
        std::cout << "RosMagneticFieldToH5Writer only supports sensor_msgs/MagneticField messages\n";
        assert(false);
    }

    // Add the group, if it does not already exist
    addGroup(path_group);

    // Write meta information as attributes to the group
    writeAttributeToObject(path_group, "ros_message_type", connections[0]->datatype);
    writeAttributeToObject<std::string>(path_group, "frame", "IMU");

    // Create datasets, with units and descriptors written as attributes
    size_t n_messages = view_topic.size();

    std::string path_timestamp_dataset = path_group + "/timestamps";
    addDataset<uint64_t>(path_timestamp_dataset, n_messages);
    writeAttributeToObject<std::string>(path_timestamp_dataset, "units", "nanoseconds");

    std::string path_magnetic_fields_dataset = path_group + "/magnetic_fields";
    std::vector<hsize_t> dimensions_magnetic_field{3};
    addDataset<double>(path_magnetic_fields_dataset, n_messages, dimensions_magnetic_field);
    writeAttributeToObject<std::string>(path_magnetic_fields_dataset, "units", "Gauss");
    writeAttributeToObject<std::string>(path_magnetic_fields_dataset, "column order", "x, y, z");

    size_t message_count = 0;
    std::vector<uint64_t> timestamps_to_write;
    std::vector<double> magnetic_fields_to_write;
    for (rosbag::MessageInstance const message_instance : view_topic)
    {
        sensor_msgs::MagneticField::Ptr message_magnetic_field =
            message_instance.instantiate<sensor_msgs::MagneticField>();

        timestamps_to_write.push_back(message_magnetic_field->header.stamp.toNSec() - time_shift_camera_to_imu_);
        magnetic_fields_to_write.push_back(message_magnetic_field->magnetic_field.x);
        magnetic_fields_to_write.push_back(message_magnetic_field->magnetic_field.y);
        magnetic_fields_to_write.push_back(message_magnetic_field->magnetic_field.z);
        if (timestamps_to_write.size() == chunk_length_)
        {
            size_t index_message = message_count - chunk_length_ + 1;
            writeDataToDataset(path_timestamp_dataset, timestamps_to_write, index_message, chunk_length_);
            writeDataToDataset(path_magnetic_fields_dataset, magnetic_fields_to_write, index_message,
                chunk_length_);
            timestamps_to_write.clear();
            magnetic_fields_to_write.clear();
        }

        message_count++;

        if (message_count % chunk_length_ == 0)
        {
            std::cout << "\33[2K\rPercent completion: " << 100.0 * message_count / n_messages << std::flush;
        }
    }

    // Write any remaining messages that didn't fit perfectly in a chunk
    if (timestamps_to_write.size() > 0)
    {
        size_t index_message = message_count - timestamps_to_write.size();
        writeDataToDataset(path_timestamp_dataset, timestamps_to_write, index_message, timestamps_to_write.size());
        writeDataToDataset(path_magnetic_fields_dataset, magnetic_fields_to_write, index_message,
            timestamps_to_write.size());
    }

    std::cout << "\33[2K\rPercent completion: " << 100.0 << std::flush << std::endl;
}