#include "h5_io/ros_to_h5/RosTemperatureToH5Writer.h"

#include <cassert>
#include <iostream>

#include <rosbag/view.h>
#include <sensor_msgs/Temperature.h>

RosTemperatureToH5Writer::RosTemperatureToH5Writer(
    const int chunk_length,
    const int chunk_cache_size,
    const bool shuffle_enable,
    const std::shared_ptr<const CompressionMethod> compression_method,
    const std::shared_ptr<H5::H5File> h5_file,
    const uint64_t time_shift_camera_to_imu)
    :   RosMessageToH5Writer(
            chunk_length,
            chunk_cache_size,
            shuffle_enable,
            compression_method,
            h5_file),
        time_shift_camera_to_imu_(time_shift_camera_to_imu)
{}

void RosTemperatureToH5Writer::writeRosbagTopicView(
    const std::string path_group,
    rosbag::View& view_topic)
{
    std::vector<const rosbag::ConnectionInfo*> connections = view_topic.getConnections();

    // Check that the view only has a single topic
    if (connections.size() > 1)
    {
        std::cout << "writeRosbagTopicView only supports views of a single topic\n";
        assert(false);
    }

    // Check the message type
    if (connections[0]->datatype != "sensor_msgs/Temperature")
    {
        std::cout << "RosTemperatureToH5Writer only supports sensor_msgs/Temperature messages\n";
        assert(false);
    }

    // Add the group, if it does not already exist
    addGroup(path_group);

    // Write meta information as attributes to the group
    writeAttributeToObject(path_group, "ros_message_type", connections[0]->datatype);

    // Create datasets, with units and descriptors written as attributes
    size_t n_messages = view_topic.size();

    std::string path_timestamp_dataset = path_group + "/timestamps";
    addDataset<uint64_t>(path_timestamp_dataset, n_messages);
    writeAttributeToObject<std::string>(path_timestamp_dataset, "units", "nanoseconds");

    std::string path_temperatures_dataset = path_group + "/temperatures";
    addDataset<double>(path_temperatures_dataset, n_messages);
    writeAttributeToObject<std::string>(path_temperatures_dataset, "units", "Celsius");

    size_t message_count = 0;
    std::vector<uint64_t> timestamps_to_write;
    std::vector<double> temperatures_to_write;
    for (rosbag::MessageInstance const message_instance : view_topic)
    {
        sensor_msgs::Temperature::Ptr message_temperature = message_instance.instantiate<sensor_msgs::Temperature>();

        timestamps_to_write.push_back(message_temperature->header.stamp.toNSec() - time_shift_camera_to_imu_);
        temperatures_to_write.push_back(message_temperature->temperature);
        if (timestamps_to_write.size() == chunk_length_)
        {
            size_t index_message = message_count - chunk_length_ + 1;
            writeDataToDataset(path_timestamp_dataset, timestamps_to_write, index_message, chunk_length_);
            writeDataToDataset(path_temperatures_dataset, temperatures_to_write, index_message, chunk_length_);
            timestamps_to_write.clear();
            temperatures_to_write.clear();
        }

        message_count++;

        if (message_count % chunk_length_ == 0)
        {
            std::cout << "\33[2K\rPercent completion: " << 100.0 * message_count / n_messages << std::flush;
        }
    }

    // Write any remaining messages that didn't fit perfectly in a chunk
    if (timestamps_to_write.size() > 0)
    {
        size_t index_message = message_count - timestamps_to_write.size();
        writeDataToDataset(path_timestamp_dataset, timestamps_to_write, index_message, timestamps_to_write.size());
        writeDataToDataset(path_temperatures_dataset, temperatures_to_write, index_message, timestamps_to_write.size());
    }

    std::cout << "\33[2K\rPercent completion: " << 100.0 << std::flush << std::endl;
}