#include "h5_io/h5_to_common/H5ToCommonMagneticFieldWriter.h"

#include <cassert>
#include <iostream>
#include <fstream>
#include <iomanip>

H5ToCommonMagneticFieldWriter::H5ToCommonMagneticFieldWriter(H5::Group& group)
    :   H5ToCommonWriter(group)
{}

void H5ToCommonMagneticFieldWriter::writeH5TopicGroup(const std::string path_output)
{
    // Initialize the CSV file
    std::ofstream file_magnetic_fields;
    file_magnetic_fields.open(path_output);
    file_magnetic_fields << std::setprecision(17);
    file_magnetic_fields << "timestamp, "
        "x_magnetic_field, y_magnetic_field, z_magnetic_field, \n";

    // Read in the data chunk by chunk
    size_t n_messages_read = 0;
    size_t message_count = 0;
    std::vector<uint64_t> data_timestamps;
    std::vector<double> data_magnetic_fields;
    while (message_count < n_messages_)
    {
        readNextChunkFromDataset("timestamps", data_timestamps, n_messages_read);
        readNextChunkFromDataset("magnetic_fields", data_magnetic_fields, n_messages_read);

        for (size_t i = 0; i < n_messages_read; i++)
        {
            file_magnetic_fields << data_timestamps[i] << ", ";
            file_magnetic_fields << data_magnetic_fields[i * 3] << ", ";
            file_magnetic_fields << data_magnetic_fields[i * 3 + 1] << ", ";
            file_magnetic_fields << data_magnetic_fields[i * 3 + 2] << ", ";
            file_magnetic_fields << "\n";
        }

        message_count += n_messages_read;
        std::cout << "\33[2K\rPercent completion: " << 100.0 * message_count / n_messages_ << std::flush;
    }
    std::cout << "\33[2K\rPercent completion: " << 100.0 << std::flush << std::endl;
}
