#include "h5_io/h5_to_common/H5ToCommonTemperatureWriter.h"

#include <cassert>
#include <iostream>
#include <fstream>
#include <iomanip>

H5ToCommonTemperatureWriter::H5ToCommonTemperatureWriter(H5::Group& group)
    :   H5ToCommonWriter(group)
{}

void H5ToCommonTemperatureWriter::writeH5TopicGroup(const std::string path_output)
{
    // Initialize the CSV file
    std::ofstream file_temperatures;
    file_temperatures.open(path_output);
    file_temperatures << std::setprecision(17);
    file_temperatures << "timestamp, temperature, \n";

    // Read in the data chunk by chunk
    size_t n_messages_read = 0;
    size_t message_count = 0;
    std::vector<uint64_t> data_timestamps;
    std::vector<double> data_temperature;
    while (message_count < n_messages_)
    {
        readNextChunkFromDataset("timestamps", data_timestamps, n_messages_read);
        readNextChunkFromDataset("temperatures", data_temperature, n_messages_read);

        for (size_t i = 0; i < n_messages_read; i++)
        {
            file_temperatures << data_timestamps[i] << ", ";
            file_temperatures << data_temperature[i] << ", ";
            file_temperatures << "\n";
        }

        message_count += n_messages_read;
        std::cout << "\33[2K\rPercent completion: " << 100.0 * message_count / n_messages_ << std::flush;
    }
    std::cout << "\33[2K\rPercent completion: " << 100.0 << std::flush << std::endl;
}
