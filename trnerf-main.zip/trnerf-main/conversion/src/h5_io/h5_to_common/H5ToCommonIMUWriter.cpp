#include "h5_io/h5_to_common/H5ToCommonIMUWriter.h"

#include <cassert>
#include <iostream>
#include <fstream>
#include <iomanip>

H5ToCommonIMUWriter::H5ToCommonIMUWriter(H5::Group& group)
    :   H5ToCommonWriter(group)
{}

void H5ToCommonIMUWriter::writeH5TopicGroup(const std::string path_output)
{
    // Initialize the CSV file
    std::ofstream file_imu;
    file_imu.open(path_output);
    file_imu << std::setprecision(17);
    file_imu << "timestamp, "
        "x_angular_velocity, y_angular_velocity, z_angular_velocity, "
        "x_linear_acceleration, y_linear_acceleration, z_linear_acceleration, "
        "x_quaternion, y_quaternion, z_quaternion, w_quaternion, \n";

    // Read in the data chunk by chunk
    size_t n_messages_read = 0;
    size_t message_count = 0;
    std::vector<uint64_t> data_timestamps;
    std::vector<double> data_quaternions;
    std::vector<double> data_angular_velocities;
    std::vector<double> data_linear_accelerations;
    while (message_count < n_messages_)
    {
        readNextChunkFromDataset("timestamps", data_timestamps, n_messages_read);
        readNextChunkFromDataset("quaternions", data_quaternions, n_messages_read);
        readNextChunkFromDataset("angular_velocities", data_angular_velocities, n_messages_read);
        readNextChunkFromDataset("linear_accelerations", data_linear_accelerations, n_messages_read);

        for (size_t i = 0; i < n_messages_read; i++)
        {
            file_imu << data_timestamps[i] << ", ";
            file_imu << data_angular_velocities[i * 3] << ", ";
            file_imu << data_angular_velocities[i * 3 + 1] << ", ";
            file_imu << data_angular_velocities[i * 3 + 2] << ", ";
            file_imu << data_linear_accelerations[i * 3] << ", ";
            file_imu << data_linear_accelerations[i * 3 + 1] << ", ";
            file_imu << data_linear_accelerations[i * 3 + 2] << ", ";
            file_imu << data_quaternions[i * 4] << ", ";
            file_imu << data_quaternions[i * 4 + 1] << ", ";
            file_imu << data_quaternions[i * 4 + 2] << ", ";
            file_imu << data_quaternions[i * 4 + 3] << ", ";
            file_imu << "\n";
        }

        message_count += n_messages_read;
        std::cout << "\33[2K\rPercent completion: " << 100.0 * message_count / n_messages_ << std::flush;
    }
    std::cout << "\33[2K\rPercent completion: " << 100.0 << std::flush << std::endl;
}
