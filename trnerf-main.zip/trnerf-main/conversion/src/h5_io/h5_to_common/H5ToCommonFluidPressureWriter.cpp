#include "h5_io/h5_to_common/H5ToCommonFluidPressureWriter.h"

#include <cassert>
#include <iostream>
#include <fstream>
#include <iomanip>

H5ToCommonFluidPressureWriter::H5ToCommonFluidPressureWriter(H5::Group& group)
    :   H5ToCommonWriter(group)
{}

void H5ToCommonFluidPressureWriter::writeH5TopicGroup(const std::string path_output)
{
    // Initialize the CSV file
    std::ofstream file_fluid_pressures;
    file_fluid_pressures.open(path_output);
    file_fluid_pressures << std::setprecision(17);
    file_fluid_pressures << "timestamp, fluid_pressure, \n";

    // Read in the data chunk by chunk
    size_t n_messages_read = 0;
    size_t message_count = 0;
    std::vector<uint64_t> data_timestamps;
    std::vector<double> data_fluid_pressure;
    while (message_count < n_messages_)
    {
        readNextChunkFromDataset("timestamps", data_timestamps, n_messages_read);
        readNextChunkFromDataset("fluid_pressures", data_fluid_pressure, n_messages_read);

        for (size_t i = 0; i < n_messages_read; i++)
        {
            file_fluid_pressures << data_timestamps[i] << ", ";
            file_fluid_pressures << data_fluid_pressure[i] << ", ";
            file_fluid_pressures << "\n";
        }

        message_count += n_messages_read;
        std::cout << "\33[2K\rPercent completion: " << 100.0 * message_count / n_messages_ << std::flush;
    }
    std::cout << "\33[2K\rPercent completion: " << 100.0 << std::flush << std::endl;
}
