#include "h5_io/h5_to_ros/H5ToRosTemperatureWriter.h"

#include <cassert>
#include <iostream>

#include <rosbag/view.h>
#include <sensor_msgs/Temperature.h>

H5ToRosTemperatureWriter::H5ToRosTemperatureWriter(H5::Group& group)
    :   H5ToRosMessageWriter(group)
{}

void H5ToRosTemperatureWriter::writeH5TopicGroup(
    const std::string topic,
    rosbag::Bag& bag)
{
    // Read in the data chunk by chunk
    size_t n_messages_read = 0;
    size_t message_count = 0;
    std::vector<uint64_t> data_timestamps;
    std::vector<double> data_temperatures;
    sensor_msgs::Temperature message_temperature;
    while (message_count < n_messages_)
    {
        readNextChunkFromDataset("timestamps", data_timestamps, n_messages_read);
        readNextChunkFromDataset("temperatures", data_temperatures, n_messages_read);

        // Write out the chunk data as separate temperature messages
        for (size_t i = 0; i < n_messages_read; i++)
        {
            message_temperature.header.stamp.fromNSec(data_timestamps[i]);
            message_temperature.temperature = data_temperatures[i];
            bag.write(topic, message_temperature.header.stamp, message_temperature);
        }

        message_count += n_messages_read;
        std::cout << "\33[2K\rPercent completion: " << 100.0 * message_count / n_messages_ << std::flush;
    }
    std::cout << "\33[2K\rPercent completion: " << 100.0 << std::flush << std::endl;
}
