#include "h5_io/h5_to_ros/H5ToRosIMUWriter.h"

#include <cassert>
#include <iostream>

#include <rosbag/view.h>
#include <sensor_msgs/Imu.h>

H5ToRosIMUWriter::H5ToRosIMUWriter(H5::Group& group)
    :   H5ToRosMessageWriter(group)
{}

void H5ToRosIMUWriter::writeH5TopicGroup(
    const std::string topic,
    rosbag::Bag& bag)
{
    // Read in the data chunk by chunk
    size_t n_messages_read = 0;
    size_t message_count = 0;
    std::vector<uint64_t> data_timestamps;
    std::vector<double> data_quaternions;
    std::vector<double> data_angular_velocities;
    std::vector<double> data_linear_accelerations;
    sensor_msgs::Imu message_imu;
    while (message_count < n_messages_)
    {
        readNextChunkFromDataset("timestamps", data_timestamps, n_messages_read);
        readNextChunkFromDataset("quaternions", data_quaternions, n_messages_read);
        readNextChunkFromDataset("angular_velocities", data_angular_velocities, n_messages_read);
        readNextChunkFromDataset("linear_accelerations", data_linear_accelerations, n_messages_read);

        // Write out the chunk data as separate IMU messages
        for (size_t i = 0; i < n_messages_read; i++)
        {
            message_imu.header.stamp.fromNSec(data_timestamps[i]);
            message_imu.orientation.x = data_quaternions[i * 4];
            message_imu.orientation.y = data_quaternions[i * 4 + 1];
            message_imu.orientation.z = data_quaternions[i * 4 + 2];
            message_imu.orientation.w = data_quaternions[i * 4 + 3];
            message_imu.angular_velocity.x = data_angular_velocities[i * 3];
            message_imu.angular_velocity.y = data_angular_velocities[i * 3 + 1];
            message_imu.angular_velocity.z = data_angular_velocities[i * 3 + 2];
            message_imu.linear_acceleration.x = data_linear_accelerations[i * 3];
            message_imu.linear_acceleration.y = data_linear_accelerations[i * 3 + 1];
            message_imu.linear_acceleration.z = data_linear_accelerations[i * 3 + 2];
            bag.write(topic, message_imu.header.stamp, message_imu);
        }

        message_count += n_messages_read;
        std::cout << "\33[2K\rPercent completion: " << 100.0 * message_count / n_messages_ << std::flush;
    }
    std::cout << "\33[2K\rPercent completion: " << 100.0 << std::flush << std::endl;
}
