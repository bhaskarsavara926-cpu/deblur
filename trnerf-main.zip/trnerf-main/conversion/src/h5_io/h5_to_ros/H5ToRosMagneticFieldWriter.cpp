#include "h5_io/h5_to_ros/H5ToRosMagneticFieldWriter.h"

#include <cassert>
#include <iostream>

#include <rosbag/view.h>
#include <sensor_msgs/MagneticField.h>

H5ToRosMagneticFieldWriter::H5ToRosMagneticFieldWriter(H5::Group& group)
    :   H5ToRosMessageWriter(group)
{}

void H5ToRosMagneticFieldWriter::writeH5TopicGroup(
    const std::string topic,
    rosbag::Bag& bag)
{
    // Read in the data chunk by chunk
    size_t n_messages_read = 0;
    size_t message_count = 0;
    std::vector<uint64_t> data_timestamps;
    std::vector<double> data_magnetic_fields;
    sensor_msgs::MagneticField message_magnetic_field;
    while (message_count < n_messages_)
    {
        readNextChunkFromDataset("timestamps", data_timestamps, n_messages_read);
        readNextChunkFromDataset("magnetic_fields", data_magnetic_fields, n_messages_read);

        // Write out the chunk data as separate magnetic field messages
        for (size_t i = 0; i < n_messages_read; i++)
        {
            message_magnetic_field.header.stamp.fromNSec(data_timestamps[i]);
            message_magnetic_field.magnetic_field.x = data_magnetic_fields[i * 3];
            message_magnetic_field.magnetic_field.y = data_magnetic_fields[i * 3 + 1];
            message_magnetic_field.magnetic_field.z = data_magnetic_fields[i * 3 + 2];
            bag.write(topic, message_magnetic_field.header.stamp, message_magnetic_field);
        }

        message_count += n_messages_read;
        std::cout << "\33[2K\rPercent completion: " << 100.0 * message_count / n_messages_ << std::flush;
    }
    std::cout << "\33[2K\rPercent completion: " << 100.0 << std::flush << std::endl;
}
