#!/bin/bash

output_folder=$1
trnerf_dataset_folder=$2

if [ $# -ne 2 ]
then
    echo "Two arguments are required, exiting"
    exit 1
fi

# trial_name / ablation method name in the paper
# rolling / Rolling Shutter (RS)
# blur_only / Blur, Simpsons (BS)
# riemann / RS + Blur, Riemann
# simpsons / RS + BS
# 8bit / TRNeRF, 8-bit
# filters / TRNeRF, w/ filters
declare -a trial_name_list=(\
    'rolling' \
    'blur_only' \
    'riemann' \
    'simpsons' \
    '8bit'
    'filters')
declare -a correct_rolling_shutter_list=(\
    'True' \
    'False' \
    'True' \
    'True' \
    'True' \
    'True')
declare -a correct_blur_list=(\
    'False' \
    'True' \
    'True' \
    'True' \
    'True' \
    'True')
declare -a integration_method_list=(\
    'simpsons' \
    'simpsons' \
    'riemann' \
    'simpsons' \
    'simpsons' \
    'simpsons')
declare -a fpn_list=(\
    'False' \
    'False' \
    'False' \
    'False' \
    'True' \
    'True')
declare -a convert_to_8bit_list=(\
    'False' \
    'False' \
    'False' \
    'False' \
    'True' \
    'False')
declare -a camera_list=(\
    'right' \
    'right' \
    'right' \
    'right' \
    'right' \
    'left')

for speed in slow medium fast
do
    for scene in indoor outdoor
    do
        for i in {0..5}
        do
            $(dirname "$0")/run_training.sh \
                $output_folder \
                $trnerf_dataset_folder \
                $speed \
                $scene \
                ${camera_list[$i]} \
                ${correct_rolling_shutter_list[$i]} \
                ${correct_blur_list[$i]} \
                ${integration_method_list[$i]} \
                ${fpn_list[$i]} \
                ${convert_to_8bit_list[$i]} \
                ${trial_name_list[$i]}
        done
    done
done
