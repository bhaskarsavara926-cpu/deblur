#!/bin/bash

output_folder=$1
trnerf_dataset_folder=$2
speed=$3
scene=$4
camera=$5
correct_rolling_shutter=$6
correct_blur=$7
integration_method=$8
fpn_opt=$9
convert_to_8bit=${10}
trial_name=${11}
path_two_point_nuc_results=${12}

path_two_point_nuc_results_arg=""
if [ $# -lt 11 ]
then
    echo "At least eleven arguments are required, exiting"
    exit 1
elif [ $# -gt 12 ]
then
    echo "No more than twelve arguments supported, received" $#
    exit 1
elif [ $# -eq 12 ]
then
    path_two_point_nuc_results_arg="--path-two-point-nuc-results $path_two_point_nuc_results"
fi

if [ $scene == indoor ]
then
    scale_factor=0.35
    translation='-0.37 -1.875 -0.95'
    if [ $camera == left ]
    then
        threshold_min=22768
        threshold_max=24428
        threshold_min_viz_eval=22848
        threshold_max_viz_eval=23468
    elif [ $camera == right ]
    then
        threshold_min=22756
        threshold_max=24394
        threshold_min_viz_eval=22884
        threshold_max_viz_eval=23486
    else
        echo "Invalid camera"
        exit 1
    fi
elif [ $scene == outdoor ]
then
    scale_factor=0.34
    translation='0.0 -1.32 -1.32'
    if [ $camera == left ]
    then
        threshold_min=20930
        threshold_max=26069
        threshold_min_viz_eval=22476
        threshold_max_viz_eval=25473
    elif [ $camera == right ]
    then
        threshold_min=20584
        threshold_max=26994
        threshold_min_viz_eval=22460
        threshold_max_viz_eval=25598
    else
        echo "Invalid camera"
        exit 1
    fi
else
    echo "Invalid scene"
    exit 1
fi

if [ $convert_to_8bit == True ]
then
    threshold_min=$threshold_min_viz_eval
    threshold_max=$threshold_max_viz_eval
fi

sequence=$"$speed"_$"$scene"
full_trial_name=$"$camera"_$"$sequence"_$"$trial_name"
ns-train \
    trnerf \
        --mixed-precision True \
        --gradient-accumulation-steps fields 1 fpn_opt 1 \
        --output-dir $output_folder \
        --experiment-name $full_trial_name \
        --viewer.quit-on-train-completion True \
        --pipeline.datamanager.correct-blur $correct_blur \
        --pipeline.datamanager.correct-rolling-shutter $correct_rolling_shutter \
        --pipeline.datamanager.n-blur-samples 19 \
        --pipeline.datamanager.duration-blur-samples 40e-3 \
        --pipeline.datamanager.tau 8e-3 \
        --pipeline.datamanager.readout-delay 0.5e-3 \
        --pipeline.datamanager.readout-row-duration 27.8e-6 \
        --pipeline.model.integration-method $integration_method \
        --pipeline.datamanager.train-num-images-to-sample-from 4000 \
        --pipeline.datamanager.train-num-times-to-repeat-images 5000 \
        --pipeline.datamanager.train-num-rays-per-batch 500 \
        --max-num-iterations 60000 \
        --pipeline.model.fpn-optimizer.enable $fpn_opt \
    trnerf_dataparser \
        --path-calibration-results $trnerf_dataset_folder/cam_calibration/camchain.yaml \
        --path-scaled-mono-left-poses $trnerf_dataset_folder/$sequence/pseudo_ground_truth_poses.h5 \
        --path-images $trnerf_dataset_folder/$sequence/adk_$"$camera".h5 \
        --scale-factor $scale_factor \
        --rotation 0.0 0.0 0.0 \
        --translation $translation \
        --threshold-minimum $threshold_min \
        --threshold-maximum $threshold_max \
        --threshold-minimum-viewer $threshold_min_viz_eval \
        --threshold-maximum-viewer $threshold_max_viz_eval \
        --convert-to-8bit $convert_to_8bit \
        $path_two_point_nuc_results_arg
