#!/bin/bash

output_folder=$1
trnerf_dataset_folder=$2
speed=$3
scene=$4

if [ $# -ne 4 ]
then
    echo "Four arguments are required, exiting"
    exit 1
fi

$(dirname "$0")/run_training.sh \
    $output_folder \
    $trnerf_dataset_folder \
    $speed \
    $scene \
    right \
    True \
    True \
    simpsons \
    True \
    False \
    recommended
