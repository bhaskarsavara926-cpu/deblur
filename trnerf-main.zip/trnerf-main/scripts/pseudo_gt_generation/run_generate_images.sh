#!/bin/bash

output_folder=$1
trnerf_dataset_folder=$2

if [ $# -ne 2 ]
then
    echo "Two arguments are required, exiting"
    exit 1
fi

for scene in indoor outdoor
do
    for camera in left right
    do
        # Set two point NUC timestamps
        if [ $scene == indoor ]
        then
            if [ $camera == left ]
            then
                t_start_hot=1213492796600
                t_stop_hot=1231201060943
                t_start_cold=1205780605272
                t_stop_cold=1208991259767
            elif [ $camera == right ]
            then
                t_start_hot=1493035074767
                t_stop_hot=1509849645383
                t_start_cold=1476766642591
                t_stop_cold=1491280794703
            else
                echo "Invalid camera"
                exit 1
            fi
        elif [ $scene == outdoor ]
        then
            if [ $camera == left ]
            then
                t_start_hot=1474584724695
                t_stop_hot=1480112345703
                t_start_cold=1494444446375
                t_stop_cold=1498432941055
            elif [ $camera == right ]
            then
                t_start_hot=1742459092863
                t_stop_hot=1759422590471
                t_start_cold=1764668859824
                t_stop_cold=1781185518607
            else
                echo "Invalid camera"
                exit 1
            fi
        else
            echo "Invalid scene"
            exit 1
        fi

        # Compute two point NUC
        mkdir -p $output_folder/slow_$scene
        python3 $(dirname "$0")/../../dataset_prep/compute_two_point_nuc.py \
            --path-images $trnerf_dataset_folder/slow_$scene/adk_$camera.h5 \
            --t-start-hot $t_start_hot \
            --t-stop-hot $t_stop_hot \
            --t-start-cold $t_start_cold \
            --t-stop-cold $t_stop_cold \
            --path-output $output_folder/slow_$scene/two_point_nuc_results_adk_$camera.h5

        # Run training with the two point NUC corrected slow sequence images
        mkdir -p $output_folder/training_w_two_point_output/
        $(dirname "$0")/../training/run_training.sh \
            $output_folder/training_w_two_point_output/ \
            $trnerf_dataset_folder \
            slow \
            $scene \
            $camera \
            False \
            False \
            simpsons \
            False \
            False \
            w_two_point \
            $output_folder/slow_$scene/two_point_nuc_results_adk_$camera.h5

        # Render pseudo ground truth images for the medium and fast speed sequences
        for speed in medium fast
        do
            sequence=$"$speed"_$"$scene"
            mkdir -p $output_folder/$sequence
            trial_folder=$(ls $output_folder/training_w_two_point_output/$"$camera"_slow_$"$scene"_w_two_point/trnerf/)
            path_config=$output_folder/training_w_two_point_output/$"$camera"_slow_$"$scene"_w_two_point/trnerf/$trial_folder/config.yml
            python3 $(dirname "$0")/../../trnerf_main/trnerf/render_restored.py \
                --path-config $path_config \
                --path-output-h5 $output_folder/$sequence/pseudo_ground_truth_adk_$"$camera".h5 \
                --path-calibration-results $trnerf_dataset_folder/cam_calibration/camchain.yaml \
                --path-scaled-mono-left-poses_target $trnerf_dataset_folder/$sequence/pseudo_ground_truth_poses.h5 \
                --path_images_target $trnerf_dataset_folder/$sequence/adk_$"$camera".h5
        done
    done
done
