#!/bin/bash

########################################################################################################################
# Parameters to set
########################################################################################################################

output_folder=$1
trnerf_dataset_folder=$2

if [ $# -ne 2 ]
then
    echo "Two arguments are required, exiting"
    exit 1
fi

for scene in indoor outdoor
do
    if [ $scene == indoor ]
    then
        sequence_list=(\
            'fast_indoor' \
            'medium_indoor' \
            'slow_indoor')
        t_start_list=(\
            '2410.338' \
            '1853.088' \
            '1249.052')
        t_stop_list=(\
            '2470.338' \
            '1913.088' \
            '1471.304')
    elif [ $scene == outdoor ]
    then
        sequence_list=(\
            'fast_outdoor' \
            'medium_outdoor' \
            'slow_outdoor')
        t_start_list=(\
            '2447.196' \
            '2013.322' \
            '1517.612')
        t_stop_list=(\
            '2507.196' \
            '2073.322' \
            '1739.865')
    else
        echo "Invalid scene"
        exit 1
    fi

    script_folder=$(dirname "$0")/../../dataset_prep/
    n_images_colmap_list=(\
        '600' \
        '300' \
        '100')

    # NOTE: also change --ImageReader.camera_params below if needed

    ####################################################################################################################
    # Set folder paths and create new folders
    ####################################################################################################################

    image_folder=$output_folder/pose_estimation/images/$scene/
    colmap_folder=$output_folder/pose_estimation/colmap/$scene/
    hloc_folder=$output_folder/pose_estimation/hloc/$scene/
    calibration_results_file=$trnerf_dataset_folder/cam_calibration/camchain.yaml

    mkdir -p $image_folder
    mkdir -p $colmap_folder

    ####################################################################################################################
    # Create folder of images and image lists for COLMAP and HLOC to process
    ####################################################################################################################

    paths_colmap_lists=""
    paths_hloc_lists=""
    for i in {0..2}
    do
        sequence=${sequence_list[$i]}
        n_images_colmap=${n_images_colmap_list[$i]}
        t_start=${t_start_list[$i]}
        t_stop=${t_stop_list[$i]}

        python3 $script_folder/h5_to_image_folders.py \
            --path-input-folder $trnerf_dataset_folder/$sequence/ \
            --path-output-folder $image_folder/$sequence/ \
            --n-images-colmap $n_images_colmap \
            --t-start $t_start \
            --t-stop $t_stop

        paths_colmap_lists="$paths_colmap_lists $image_folder/$sequence/image_list_mono_left_colmap.txt"
        paths_hloc_lists="$paths_hloc_lists $image_folder/$sequence/image_list_mono_left_hloc.txt $image_folder/$sequence/image_list_mono_right_hloc.txt"
    done

    python3 $script_folder/combine_image_lists.py \
        --paths-file-to-combine $paths_colmap_lists \
        --path-output-file $image_folder/image_list_mono_left_colmap.txt

    python3 $script_folder/combine_image_lists.py \
        --paths-file-to-combine $paths_hloc_lists \
        --path-output-file $image_folder/image_list_hloc.txt

    ####################################################################################################################
    # Run COLMAP to estimate sparse left monochrome poses
    ####################################################################################################################

    # Feature extraction
    # NOTE: --ImageReader.camera_params is the mono left Kalibr results:
    # fx, fy, cx, cy, k1, k2, p1, p2
    # where the principal points used here should be the ones estimated from Kalibr + 0.5
    colmap feature_extractor \
        --database_path $colmap_folder/database.db \
        --image_path $image_folder \
        --image_list_path $image_folder/image_list_mono_left_colmap.txt \
        --camera_mode 1 \
        --ImageReader.camera_model OPENCV \
        --ImageReader.camera_params "1089.9885334237777, 1085.471966486138, 720.7611271971043, 565.7831924847984, -0.3639052622561226, 0.1317757082193622, -0.000081248788859175, -0.0001429163673316175"

    # Perform feature matching
    colmap exhaustive_matcher \
        --database_path $colmap_folder/database.db

    # Sparse reconstruction
    mkdir -p $colmap_folder/sparse/
    colmap mapper \
        --database_path $colmap_folder/database.db \
        --image_path $image_folder \
        --output_path $colmap_folder/sparse/ \
        --Mapper.ba_refine_focal_length 0 \
        --Mapper.ba_refine_principal_point 0 \
        --Mapper.ba_refine_extra_params 0

    ####################################################################################################################
    # Run HLOC to estimate remaining left monochrome poses and all right monochrome camera poses
    ####################################################################################################################

    python3 $script_folder/run_hloc.py \
        --path-colmap-model $colmap_folder/sparse/0/ \
        --path-reference-image-list $image_folder/image_list_mono_left_colmap.txt \
        --path-query-image-list $image_folder/image_list_hloc.txt \
        --path-image-parent-folder $image_folder \
        --path-calibration-results $calibration_results_file \
        --path-outputs $hloc_folder \
        --parallel \
        --overwrite

    ####################################################################################################################
    # Finalize poses (combine COLMAP and HLOC poses, scale them, and write them out for each individual sequence)
    ####################################################################################################################

    python3 $script_folder/finalize_poses.py \
        --path-calibration-results $calibration_results_file \
        --path-colmap-model $colmap_folder/sparse/0/ \
        --path-hloc-poses $hloc_folder/poses_query.pickle \
        --path-image-folders $image_folder \
        --path-output-folder $output_folder
done
