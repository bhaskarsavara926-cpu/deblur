#!/bin/bash

output_folder=$1

if [ $# -ne 1 ]
then
    echo "One argument is required, exiting"
    exit 1
fi

for dir in $output_folder/*/
do
    for trial_folder in $dir/*/*/
    do
        python3 $(dirname "$0")/../../../trnerf_main/trnerf/render_restored.py \
            --path-config $trial_folder/config.yml
    done
done
