#!/bin/bash

output_folder=$1
trnerf_dataset_folder=$2

if [ $# -ne 2 ]
then
    echo "Two arguments are required, exiting"
    exit 1
fi

for speed in medium fast
do
    for scene in indoor outdoor
    do
        for camera in left right
        do
            sequence=$"$speed"_$"$scene"
            raw_trial_folder=$output_folder/$"$camera"_$"$sequence"_raw
            mkdir -p $raw_trial_folder
            $(dirname "$0")/run_lpips_metric.sh \
                $trnerf_dataset_folder/$sequence/adk_$camera.h5 \
                $raw_trial_folder \
                $trnerf_dataset_folder \
                $speed \
                $scene \
                $camera \
                True
        done
    done
done
