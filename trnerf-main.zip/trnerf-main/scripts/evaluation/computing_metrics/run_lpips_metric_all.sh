#!/bin/bash

output_folder=$1
trnerf_dataset_folder=$2

if [ $# -ne 2 ]
then
    echo "Two arguments are required, exiting"
    exit 1
fi

for dir in $output_folder/*/
do
    for trial_folder in $dir/*/*/
    do
        $(dirname "$0")/run_lpips_metric_trial.sh \
            $trial_folder \
            $trnerf_dataset_folder
    done
done
