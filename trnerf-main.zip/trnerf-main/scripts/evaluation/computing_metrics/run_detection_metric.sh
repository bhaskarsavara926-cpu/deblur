#!/bin/bash

path_thermal_images=$1
path_pickle_out_folder=$2
trnerf_dataset_folder=$3
speed=$4
scene=$5
camera=$6
undistort_thermal=$7

if [ $# -ne 7 ]
then
    echo "Seven arguments are required, exiting"
    exit 1
fi

if [ $scene == indoor ]
then
    ids_tag_row_ignore_arg=""
    if [ $camera == left ]
    then
        threshold_min_viz_eval=22848
        threshold_max_viz_eval=23468
    elif [ $camera == right ]
    then
        threshold_min_viz_eval=22884
        threshold_max_viz_eval=23486
    else
        echo "Invalid camera"
        exit 1
    fi
elif [ $scene == outdoor ]
then
    ids_tag_row_ignore_arg="--ids-tag-row-ignore 1 2 3"
    if [ $camera == left ]
    then
        threshold_min_viz_eval=22476
        threshold_max_viz_eval=25473
    elif [ $camera == right ]
    then
        threshold_min_viz_eval=22460
        threshold_max_viz_eval=25598
    else
        echo "Invalid camera"
        exit 1
    fi
else
    echo "Invalid scene"
    exit 1
fi

if [ $undistort_thermal == True ]
then
    undistort_thermal_arg="--undistort-thermal"
elif [ $undistort_thermal == False ]
then
    undistort_thermal_arg=""
else
    echo "undistort_thermal argument must be True or False, received $undistort_thermal"
    exit 1
fi

echo "Computing detection metric for $path_thermal_images"
sequence=$"$speed"_$"$scene"
python3 $(dirname "$0")/../../../evaluation/compute_detection_metric.py \
    --path-thermal-images $path_thermal_images \
    --threshold-minimum $threshold_min_viz_eval \
    --threshold-maximum $threshold_max_viz_eval \
    --name-thermal adk_$camera \
    --path-mono-left $trnerf_dataset_folder/$sequence/mono_left.h5 \
    --path-poses $trnerf_dataset_folder/$sequence/pseudo_ground_truth_poses.h5 \
    --path-calibration-results $trnerf_dataset_folder/cam_calibration/camchain.yaml \
    --path-grid-config $trnerf_dataset_folder/cam_calibration/aprilgrid.yaml \
    --path-pickle-out-folder $path_pickle_out_folder \
    $undistort_thermal_arg \
    $ids_tag_row_ignore_arg
