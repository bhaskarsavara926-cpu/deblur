#!/bin/bash

path_evaluation_images=$1
path_pickle_out_folder=$2
trnerf_dataset_folder=$3
speed=$4
scene=$5
camera=$6
undistort_evaluation=$7

if [ $# -ne 7 ]
then
    echo "Seven arguments are required, exiting"
    exit 1
fi

if [ $speed == slow ]
then
    echo "The LPIPS metric is not applicable to the slow sequences, exiting"
    exit 0
elif [ $speed == medium ]
then
    threshold_position=0.1
    threshold_rotation=10
elif [ $speed == fast ]
then
    threshold_position=0.19
    threshold_rotation=9
else
    echo "Invalid speed"
    exit 1
fi

if [ $scene == indoor ]
then
    if [ $camera == left ]
    then
        threshold_min_viz_eval=22848
        threshold_max_viz_eval=23468
    elif [ $camera == right ]
    then
        threshold_min_viz_eval=22884
        threshold_max_viz_eval=23486
    else
        echo "Invalid camera"
        exit 1
    fi
elif [ $scene == outdoor ]
then
    if [ $camera == left ]
    then
        threshold_min_viz_eval=22476
        threshold_max_viz_eval=25473
    elif [ $camera == right ]
    then
        threshold_min_viz_eval=22460
        threshold_max_viz_eval=25598
    else
        echo "Invalid camera"
        exit 1
    fi
else
    echo "Invalid scene"
    exit 1
fi

if [ $undistort_evaluation == True ]
then
    undistort_evaluation_arg="--undistort-evaluation"
elif [ $undistort_evaluation == False ]
then
    undistort_evaluation_arg=""
else
    echo "undistort_evaluation argument must be True or False, received $undistort_evaluation"
    exit 1
fi

echo "Computing LPIPS metric for $path_evaluation_images"
sequence=$"$speed"_$"$scene"
python3 $(dirname "$0")/../../../evaluation/compute_lpips_metric.py \
    --path-evaluation-images $path_evaluation_images \
    --threshold-minimum $threshold_min_viz_eval \
    --threshold-maximum $threshold_max_viz_eval \
    --name-camera adk_$camera \
    --path-pseudo-ground-truth-images $trnerf_dataset_folder/$sequence/pseudo_ground_truth_adk_$"$camera".h5 \
    --path-pseudo-ground-truth-poses $trnerf_dataset_folder/slow_$scene/pseudo_ground_truth_poses.h5 \
    --path-evaluation-poses $trnerf_dataset_folder/$sequence/pseudo_ground_truth_poses.h5 \
    --path-calibration-results $trnerf_dataset_folder/cam_calibration/camchain.yaml \
    --threshold-position $threshold_position \
    --threshold-rotation $threshold_rotation \
    --use-gpu \
    --path-pickle-out-folder $path_pickle_out_folder \
    $undistort_evaluation_arg
