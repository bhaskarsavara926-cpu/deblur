#!/bin/bash

trial_folder=$1
trnerf_dataset_folder=$2

if [ $# -ne 2 ]
then
    echo "Two arguments are required, exiting"
    exit 1
fi

if [[ $trial_folder == *"raw"* ]]
then
    echo "Skipping trial folder: $trial_folder, computing metrics with the raw images is done in a separate script"
    exit 0
fi

if [[ $trial_folder == *"slow"* ]]
then
    speed=slow
elif [[ $trial_folder == *"medium"* ]]
then
    speed=medium
elif [[ $trial_folder == *"fast"* ]]
then
    speed=fast
else
    echo "Could not determine the speed from the trial folder path"
    exit 1
fi

if [[ $trial_folder == *"indoor"* ]]
then
    scene=indoor
elif [[ $trial_folder == *"outdoor"* ]]
then
    scene=outdoor
else
    echo "Could not determine the scene from the trial folder path"
    exit 1
fi

if [[ $trial_folder == *"left"* ]]
then
    camera=left
elif [[ $trial_folder == *"right"* ]]
then
    camera=right
else
    echo "Could not determine the camera from the trial folder path"
    exit 1
fi

$(dirname "$0")/run_detection_metric.sh \
    $trial_folder/restored.h5 \
    $trial_folder \
    $trnerf_dataset_folder \
    $speed \
    $scene \
    $camera \
    False
