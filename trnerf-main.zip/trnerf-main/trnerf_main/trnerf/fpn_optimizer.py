"""
Fixed Pattern Noise (FPN) optimizer.
"""

from dataclasses import dataclass, field
from typing import Type, Union
from jaxtyping import Float, Int
import torch
from torch import nn, Tensor

from nerfstudio.configs.base_config import InstantiateConfig

@dataclass
class FPNOptimizerConfig(InstantiateConfig):
    """FPN optimizer config."""

    _target: Type = field(default_factory=lambda: FPNOptimizer)
    """Target class to instantiate."""
    enable: bool = True
    """Whether to enable joint learning of FPN offsets."""
    penalty: float = 1e-3
    """FPN offset loss coefficient."""

class FPNOptimizer(nn.Module):
    """FPN optimizer

    This class optimizes an estimate of Fixed Pattern Noise (FPN) modeled as a pixelwise offset.

    Args:
        config: The FPNOptimizerConfig used to instantiate class
        height: Height of the thermal images
        width: Width of the thermal images
        device: Device on which to store the parameters
    """

    config: FPNOptimizerConfig

    def __init__(
        self,
        config: FPNOptimizerConfig,
        height: int,
        width: int,
        device: Union[torch.device, str],
    ):
        super().__init__()
        self.config = config
        self.device = device

        # If enabled, initialize the learnable parameters
        if self.config.enable:
            self.offsets = torch.nn.Parameter(torch.zeros((height, width), device=device))

    def forward(
        self,
        x: Int[Tensor, "num_rays"],
        y: Int[Tensor, "num_rays"],
        pixel_values_noise_free: Float[Tensor, "num_rays 3"],
    ) -> Float[Tensor, "num_rays 3"]:
        """Apply the learned FPN offsets to the input noise-free pixel values.

        Args:
            x: The x coordinates corresponding to the input pixel values.
            y: The y coordinates corresponding to the input pixel values.
            pixel_values_noise_free: The input pixel values.
        """
        if not self.config.enable:
            return pixel_values_noise_free
        pixel_values_noisy = pixel_values_noise_free + self.offsets[y, x]
        return pixel_values_noisy

    def get_loss_dict(self, loss_dict: dict) -> None:
        """Add the FPN optimizer loss to the loss dictionary

        Args:
            loss_dict: The loss dictionary.
        """
        if self.config.enable:
            loss_dict["fpn_regularizer"] = (self.offsets.mean().abs() * self.config.penalty)

    def get_param_groups(self, param_groups: dict) -> None:
        """Add the FPN optimizer parameters to the parameters dictionary

        Args:
            param_groups: The parameters dictionary.
        """
        if self.config.enable:
            param_groups["fpn_opt"] = list(self.parameters())
