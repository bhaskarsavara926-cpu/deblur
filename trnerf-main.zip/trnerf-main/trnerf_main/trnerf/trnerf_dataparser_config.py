"""
TRNeRF dataparser configuration file.
"""

from nerfstudio.plugins.registry_dataparser import DataParserSpecification

from trnerf.trnerf_dataparser import TRNeRFDataParserConfig

trnerf_dataparser = DataParserSpecification(
    config=TRNeRFDataParserConfig(),
    description="TRNeRF dataset parser",
)
