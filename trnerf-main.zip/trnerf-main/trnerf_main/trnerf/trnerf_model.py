"""
TRNeRF model.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Literal, Optional, Type, Union
import torch

from nerfstudio.models.instant_ngp import InstantNGPModelConfig, NGPModel
from nerfstudio.cameras.rays import RayBundle

from trnerf.fpn_optimizer import FPNOptimizerConfig
from trnerf.trnerf_datamanager import TRNeRFDataManagerConfig

@dataclass
class TRNeRFModelConfig(InstantNGPModelConfig):
    """TRNeRF model config."""

    _target: Type = field(default_factory=lambda: TRNeRFModel)
    """Target class to instantiate"""
    integration_method: Literal["simpsons", "riemann"] = "simpsons"
    """The method for approximating the thermal motion blur integral."""
    fpn_optimizer: FPNOptimizerConfig = field(default_factory=lambda: FPNOptimizerConfig())
    """FPN optimizer config."""

class TRNeRFModel(NGPModel):
    """TRNeRF model.

    Args:
        config: TRNeRF configuration to instantiate model.
        metadata: The data parser outputs metadata that specifies threshold arguments needed here to prepare output for
            the viewer.
        trnerf_datamanager_config: TRNeRF data manager config that specifies arguments related to blur and rolling
            shutter correction.
        height: Height of the thermal images
        width: Width of the thermal images
    """

    def __init__(
        self,
        config: TRNeRFModelConfig,
        metadata: Dict,
        trnerf_datamanager_config: TRNeRFDataManagerConfig,
        height: int,
        width: int,
        **kwargs,
    ):
        # Set the width and height (these will be used to initialize the FPN optimizer when the base class Model
        # constructor calls populate_modules)
        self.height = height
        self.width = width

        # Call the NGPModel constructor
        super().__init__(config=config, **kwargs)

        # Unpack the data parser outputs metadata
        self.threshold_minimum = metadata['threshold_minimum']
        self.threshold_maximum = metadata['threshold_maximum']
        self.threshold_minimum_viewer = metadata['threshold_minimum_viewer']
        self.threshold_maximum_viewer = metadata['threshold_maximum_viewer']

        # Unpack the TRNeRF data manager config
        self.correct_blur = trnerf_datamanager_config.correct_blur
        self.n_blur_samples = trnerf_datamanager_config.n_blur_samples
        self.duration_blur_samples = trnerf_datamanager_config.duration_blur_samples
        self.tau = trnerf_datamanager_config.tau

        assert not (self.config.integration_method == "simpsons" and self.n_blur_samples % 2 == 0), \
            "Simpson's rule requires an odd number of samples."

    def populate_modules(self) -> None:
        """Set the fields and modules."""
        super().populate_modules()

        self.fpn_optimizer = self.config.fpn_optimizer.setup(height=self.height, width=self.width, device="cpu")

    def get_param_groups(self) -> Dict[str, List[torch.nn.Parameter]]:
        """Obtain the parameter groups for the optimizers."""
        param_groups = super().get_param_groups()
        self.fpn_optimizer.get_param_groups(param_groups=param_groups)

        return param_groups

    def get_outputs(self, ray_bundle: RayBundle) -> Dict[str, Union[torch.Tensor, List]]:
        """Takes in a ray bundle and returns a dictionary of outputs.

        Args:
            ray_bundle: Input bundle of rays.
        """
        outputs = super().get_outputs(ray_bundle)
        pixel_values_ideal = outputs['rgb']

        # If not training, return the existing outputs unmodified and add an additional output for the viewer
        if not self.training:
            # Rescale the rendered pixel values to the original 16-bit range
            viewer_output = pixel_values_ideal * (self.threshold_maximum - self.threshold_minimum) + \
                self.threshold_minimum

            # Apply new thresholds to yield higher contrast for the viewer
            viewer_output[viewer_output < self.threshold_minimum_viewer] = self.threshold_minimum_viewer
            viewer_output[viewer_output > self.threshold_maximum_viewer] = self.threshold_maximum_viewer
            viewer_output = (viewer_output - self.threshold_minimum_viewer) / \
                (self.threshold_maximum_viewer - self.threshold_minimum_viewer)
            outputs['viewer_output'] = viewer_output

            return outputs

        x = ray_bundle.metadata['x']
        y = ray_bundle.metadata['y']
        if self.correct_blur:
            # Set the sample weights according to the numerical integration method selected
            if self.config.integration_method == "simpsons":
                integral_weights = torch.ones(self.n_blur_samples, device=self.device) / 3
                integral_weights[1:-1:2] *= 4
                integral_weights[2:-2:2] *= 2
            else: # riemann
                integral_weights = torch.ones(self.n_blur_samples, device=self.device)

            # Compute the discrete approximation of the microbolometer blur integral
            n_pixels = int(pixel_values_ideal.shape[0] / self.n_blur_samples)
            time_blur_samples = torch.linspace(0, self.duration_blur_samples, self.n_blur_samples, device=self.device)
            pixel_values_blurry = (1 / self.tau) * (self.duration_blur_samples / (self.n_blur_samples - 1)) * \
                torch.sum(
                    integral_weights.reshape(self.n_blur_samples, 1, 1) *
                    torch.exp(-time_blur_samples /  self.tau).reshape(self.n_blur_samples, 1, 1) *
                    pixel_values_ideal.reshape(self.n_blur_samples, n_pixels, 3),
                    dim=0)

            # Apply the FPN offsets
            pixel_values_raw = self.fpn_optimizer(x[:n_pixels], y[:n_pixels], pixel_values_blurry)

            # Retain the other outputs only at the time of readout
            outputs['accumulation'] = outputs['accumulation'][:n_pixels]
            outputs['depth'] = outputs['depth'][:n_pixels]
        else:
            # Apply the FPN offsets
            pixel_values_raw = self.fpn_optimizer(x, y, pixel_values_ideal)
        outputs['rgb'] = pixel_values_raw

        return outputs

    def get_loss_dict(
        self,
        outputs: Dict[str, Union[torch.Tensor, List]],
        batch: Dict,
        metrics_dict: Optional[Dict] = None,
    ) -> Dict[str, torch.Tensor]:
        """Computes and returns the losses dictionary.

        Args:
            outputs: The output to compute the rendering loss with
            batch: Measured pixel values against which to compute the rendering loss
            metrics_dict: Unused argument from the base Model class
        """
        rgb_loss = self.rgb_loss(batch["image"].to(self.device), outputs["rgb"])
        loss_dict = {"rgb_loss": rgb_loss}
        self.fpn_optimizer.get_loss_dict(loss_dict)

        return loss_dict
