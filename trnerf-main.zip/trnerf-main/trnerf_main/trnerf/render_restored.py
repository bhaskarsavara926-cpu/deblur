"""
Script for rendering restored thermal images
"""

from typing import Optional
import tyro
from dataclasses import dataclass
import cv2
import h5py
import torch
import numpy as np
from pathlib import Path
from tqdm import tqdm
import os

from nerfstudio.utils.eval_utils import eval_setup
from nerfstudio.cameras.cameras import Cameras

from trnerf.trnerf_dataparser import TRNeRFDataParserConfig

def convert_3x4_transformations_to_4x4(transformations_3x4):
    if len(transformations_3x4.shape) > 2:
        transformations_4x4 = torch.zeros(transformations_3x4.shape[0], 4, 4)
    elif len(transformations_3x4.shape) == 2:
        transformations_4x4 = torch.zeros(4, 4)
    else:
        return None
    transformations_4x4[..., 3, 3] = 1
    transformations_4x4[..., :3, :] = transformations_3x4

    return transformations_4x4

@dataclass
class RenderRestored:
    """Render restored images for each frame in a sequence."""

    path_config: Path
    """Path to config YAML file."""
    path_output_h5: Optional[Path] = None
    """Path to output H5 file. If None, the output data will be written to a file named restored.h5 in the same folder
    as the config YAML file"""
    path_calibration_results: Optional[Path] = None
    """Path to Kalibr camchain YAML file. If None, the source and target sequence are assumed to be the same."""
    path_scaled_mono_left_poses_target: Optional[Path] = None
    """Path to H5 file with scaled poses for the left monochrome camera, corresponding to the target sequence. If None,
    the source and target sequence are assumed to be the same."""
    path_images_target: Optional[Path] = None
    """Path to H5 file with the images to process, corresponding to the target sequence. If None, the source and target
    sequence are assumed to be the same."""
    eval_num_rays_per_chunk: int = 4096
    """Number of rays per forward pass. Reduce to fit GPU memory if needed."""

    def main(self) -> None:
        # Load the pipeline and config
        config, pipeline, _, _ = eval_setup(self.path_config, self.eval_num_rays_per_chunk, test_mode="inference")

        # Get the dataparser outputs for the source sequence
        dataparser_outputs_source = config.pipeline.datamanager.dataparser.setup().get_dataparser_outputs(split='train')

        # Get the poses at which to render
        if self.path_calibration_results and self.path_scaled_mono_left_poses_target and self.path_images_target:
            # Get the dataparser outputs for the target sequence
            dataparser_target = TRNeRFDataParserConfig(
                path_calibration_results=self.path_calibration_results,
                path_scaled_mono_left_poses=self.path_scaled_mono_left_poses_target,
                path_images=self.path_images_target).setup()
            dataparser_outputs_target = dataparser_target.get_dataparser_outputs(split='train')

            # Get the poses from the target sequence
            poses_cgl_to_wf_target_scaled = dataparser_outputs_target.cameras.camera_to_worlds
            poses_cgl_to_wf_target_scaled = convert_3x4_transformations_to_4x4(poses_cgl_to_wf_target_scaled)

            # Transform the poses from the target sequence final world frame to the COLMAP world frame
            transformation_world_to_wf_target = dataparser_outputs_target.dataparser_transform
            transformation_world_to_wf_target = convert_3x4_transformations_to_4x4(transformation_world_to_wf_target)
            scale_factor_target = dataparser_outputs_target.dataparser_scale
            poses_cgl_to_wf_target = torch.clone(poses_cgl_to_wf_target_scaled)
            poses_cgl_to_wf_target[:, :3, 3] /= scale_factor_target
            transformation_wf_target_to_world = torch.inverse(transformation_world_to_wf_target)
            poses_cgl_to_world = transformation_wf_target_to_world @ poses_cgl_to_wf_target

            # Transform the poses from the COLMAP world frame to the source sequence final world frame
            transformation_world_to_wf_source = dataparser_outputs_source.dataparser_transform
            transformation_world_to_wf_source = convert_3x4_transformations_to_4x4(transformation_world_to_wf_source)
            scale_factor_source = dataparser_outputs_source.dataparser_scale
            poses_cgl_to_wf_source = transformation_world_to_wf_source @ poses_cgl_to_world
            poses_cgl_to_wf_source_scaled = torch.clone(poses_cgl_to_wf_source)
            poses_cgl_to_wf_source_scaled[:, :3, 3] *= scale_factor_source
        else:
            poses_cgl_to_wf_source_scaled = dataparser_outputs_source.cameras.camera_to_worlds
            dataparser_outputs_target = dataparser_outputs_source

        # Compute the camera matrix to use for rendering
        camera_matrix = dataparser_outputs_target.cameras.get_intrinsics_matrices()[0].cpu().numpy()
        camera_matrix[0, 2] -= 0.5 # COLMAP and OpenCV disagree on pixel coord. convention
        camera_matrix[1, 2] -= 0.5
        distortion_coefficients = dataparser_outputs_target.cameras.distortion_params[0].cpu().numpy()
        width = int(dataparser_outputs_target.cameras.width[0, 0].cpu().numpy())
        height = int(dataparser_outputs_target.cameras.height[0, 0].cpu().numpy())
        distortion_coefficients = np.array([distortion_coefficients[0], distortion_coefficients[1],
            distortion_coefficients[4], distortion_coefficients[5]])
        camera_matrix_ideal, _ = cv2.getOptimalNewCameraMatrix(camera_matrix, distortion_coefficients, (width, height),
            alpha=0) # Using alpha = 0 to ensure no invalid pixels

        # Create the camera path
        camera_matrix_ideal[0, 2] += 0.5 # COLMAP and OpenCV disagree on pixel coord. convention
        camera_matrix_ideal[1, 2] += 0.5
        camera_path = Cameras(
            fx=float(camera_matrix_ideal[0, 0]),
            fy=float(camera_matrix_ideal[1, 1]),
            cx=float(camera_matrix_ideal[0, 2]),
            cy=float(camera_matrix_ideal[1, 2]),
            height=height,
            width=width,
            camera_type=dataparser_outputs_target.cameras.camera_type[0],
            camera_to_worlds=poses_cgl_to_wf_source_scaled[:, :3, :])
        camera_path = camera_path.to(pipeline.device)

        # Initialize the output H5 file
        if self.path_output_h5 is None:
            self.path_output_h5 = self.path_config.parent / 'restored.h5'
        h5_file = h5py.File(self.path_output_h5, 'w')
        group_image_rendered = h5_file.create_group('image_rendered')
        group_image_rendered.attrs['ros_message_type'] = np.array('sensor_msgs/Image'.encode('ascii'),
            dtype=h5py.string_dtype('ascii'))
        group_image_rendered.attrs['height'] = np.uint32(height)
        group_image_rendered.attrs['width'] = np.uint32(width)
        group_image_rendered.attrs['is_bigendian'] = np.uint8(0)
        if not config.pipeline.datamanager.dataparser.convert_to_8bit:
            group_image_rendered.attrs['encoding'] = \
                np.array('mono16'.encode('ascii'), dtype=h5py.string_dtype('ascii'))
            group_image_rendered.attrs['step'] = np.uint32(width * 2)
            dataset_images = group_image_rendered.create_dataset(name='images', shape=(camera_path.size, height, width),
                dtype=np.uint16)
        else:
            group_image_rendered.attrs['encoding'] = \
                np.array('mono8'.encode('ascii'), dtype=h5py.string_dtype('ascii'))
            group_image_rendered.attrs['step'] = np.uint32(width)
            dataset_images = group_image_rendered.create_dataset(name='images', shape=(camera_path.size, height, width),
                dtype=np.uint8)
        dataset_timestamps = group_image_rendered.create_dataset(name='timestamps', shape=(camera_path.size,),
            dtype=np.uint64)
        dataset_timestamps.attrs['units'] = 'nanoseconds'

        # Set the timestamps
        dataset_timestamps[:] = \
            np.round(dataparser_outputs_target.cameras.times[:, 0].cpu().numpy() * 1e9).astype(np.uint64)

        # Loop through cameras, render images, and store the rendered images
        try:
            print('Rendering images')
            for index_camera in tqdm(range(camera_path.size)):
                with torch.no_grad():
                    outputs = pipeline.model.get_outputs_for_camera(camera_path[index_camera : index_camera + 1])
                image_rendered = torch.mean(outputs['rgb'], dim=2).cpu().numpy()

                # Rescale and convert the rendered image
                if not config.pipeline.datamanager.dataparser.convert_to_8bit:
                    threshold_minimum = config.pipeline.datamanager.dataparser.threshold_minimum
                    threshold_maximum = config.pipeline.datamanager.dataparser.threshold_maximum
                    image_rendered = (image_rendered * (threshold_maximum - threshold_minimum) +
                        threshold_minimum).astype(np.uint16)
                else:
                    image_rendered = (image_rendered * 255.0).astype(np.uint8)

                # Write out the rendered image
                dataset_images[index_camera] = image_rendered
        except Exception as e:
            print(f'An error occurred during rendering: {e}')
            print('If it is a GPU memory issue, consider reducing the number of rays per batch with the '
                  '--eval-num-rays-per-chunk argument.')

            # Delete the preallocated H5 file
            os.remove(self.path_output_h5)

if __name__ == "__main__":
    tyro.cli(RenderRestored).main()
