"""
TRNeRF camera pose interpolator.
"""

from typing import Union
from jaxtyping import Int, Float
from scipy.interpolate import CubicSpline
from scipy.spatial.transform import Rotation, Slerp
import numpy as np
import torch

from nerfstudio.cameras.cameras import Cameras, CameraType
from nerfstudio.cameras import camera_utils
from nerfstudio.cameras.rays import RayBundle

class TRNeRFCameraPoseInterpolator:
    """TRNeRF camera pose interpolator.

    This class supports ray generation at interpolated camera poses.

    Args:
        cameras: Camera objects containing camera info.
    """

    def __init__(self, cameras: Cameras):
        self.cameras = cameras
        timestamps = cameras.times[:, 0].cpu().numpy()
        poses = cameras.camera_to_worlds.cpu().numpy()
        self.interpolator_position_cubic = CubicSpline(timestamps, poses[:, :3, 3], axis=0, extrapolate=False)
        self.interpolator_orientation_slerp = Slerp(timestamps, Rotation.from_matrix(poses[:, :3, :3]))

    def generate_rays(
        self,
        camera_indices: Union[Int[torch.Tensor, "num_rays"], int],
        coords: Float[torch.Tensor, "num_rays 2"],
        time_offsets: Float[torch.Tensor, "num_rays"],
    ) -> RayBundle:
        """Generates rays for the specified pixel coordinates using interpolated camera poses.

        This function is a modification of _generate_rays_from_coords from the nerfstudio Cameras class. The only
        necessary difference is that the camera to world transformation matrices (c2w) are computed through
        interpolation. However, for readability, the function has additionally been reduced to only the required
        components (e.g., support for multiple camera types has been removed).

        Args:
            camera_indices: Cameras (images) to generate rays for.
            coords: Coordinates of the pixels to generate rays for.
            time_offsets: Time offsets (in seconds) to be applied when generating the rays. Specifically, the time
                offset is added to the timestamp of the camera/image to determine the timestamp at which to compute
                the interpolated camera pose. The interpolated camera pose is then used in the generation of the ray.
        """
        # Check shapes
        assert len(camera_indices.shape) == 1 and len(self.cameras.shape) == 1
        assert camera_indices.shape[0] == coords.shape[0]
        assert coords.shape[-1] == 2
        assert camera_indices.shape[0] == time_offsets.shape[0]

        # Check that all cameras are perspective cameras
        assert torch.all(torch.eq(self.cameras.camera_type, CameraType.PERSPECTIVE.value))

        # Ensure inputs are on the same device as the cameras instance
        camera_indices = camera_indices.to(self.cameras.device)
        coords = coords.to(self.cameras.device)
        time_offsets = time_offsets.to(self.cameras.device)

        # Compute interpolated camera poses
        timestamps = self.cameras.times[camera_indices, 0] + time_offsets
        timestamps = timestamps.cpu().numpy()
        positions = self.interpolator_position_cubic(timestamps)
        rotations = self.interpolator_orientation_slerp(timestamps).as_matrix()
        poses = np.concatenate([rotations, np.expand_dims(positions, axis=2)], 2)
        c2w = torch.from_numpy(poses).to(self.cameras.device).float() # (num_rays, 3, 4)

        # Unpack the distorted pixel coordinates
        y = coords[:, 0] # (num_rays,) (v' in the TRNeRF paper)
        x = coords[:, 1] # (num_rays,) (u' in the TRNeRF paper)

        # Unpack the focal lengths and principal points
        fx, fy = self.cameras.fx[camera_indices].squeeze(-1), self.cameras.fy[camera_indices].squeeze(-1) # (num_rays,)
        cx, cy = self.cameras.cx[camera_indices].squeeze(-1), self.cameras.cy[camera_indices].squeeze(-1) # (num_rays,)

        # Compute the distorted normalized coordinates (x_n' in the TRNeRF paper)
        coord = torch.stack([(x - cx) / fx, (y - cy) / fy], -1)  # (num_rays, 2)

        # Compute the distorted normalized coordinates for the pixel coords offset by 1 (used to compute pixel area)
        coord_x_offset = torch.stack([(x - cx + 1) / fx, (y - cy) / fy], -1)  # (num_rays, 2)
        coord_y_offset = torch.stack([(x - cx) / fx, (y - cy + 1) / fy], -1)  # (num_rays, 2)

        # Compute the undistorted normalized coordinates (x_n in the TRNeRF paper)
        distortion_params = self.cameras.distortion_params[camera_indices]
        coord_stack = torch.stack([coord, coord_x_offset, coord_y_offset], dim=0)  # (3, num_rays, 2)
        coord_stack = camera_utils.radial_and_tangential_undistort(coord_stack, distortion_params) # (3, num_rays, 2)

        # Switch from the OpenCV (x right, y down, z forward) convention to that of OpenGL (x right, y up, z back)
        # Here, the coord_stack contains only the x and y components of the normalized coordinates, so only the y
        # coordinate needs its sign flipped
        coord_stack[..., 1] *= -1

        # Add the z component to the undistorted normalized coordinates (in the OpenGL convention)
        directions_stack = torch.empty((3,) + camera_indices.shape + (3,), device=self.cameras.device)
        directions_stack[..., 0] = coord_stack[..., 0].float()
        directions_stack[..., 1] = coord_stack[..., 1].float()
        directions_stack[..., 2] = -1.0 # (3, num_rays, 3)

        # Compute the ray directions (d in the TRNeRF paper)
        # NOTE: the second line, which rotates the normalized coordinate vectors into the world frame, works as follows:
        # 1. directions_stack[..., None, :] has shape (3, num_rays, 1, 3) (None introduces a singleton dimension)
        # 2. directions_stack[..., None, :] * rotations is an elementwise multiplication. Each tensor is broadcast to
        #   the shape (3, num_rays, 3, 3).
        # 3. After the sum along the last dimension, the result is the matrix-vector product of the rotations matrices
        #   with the direction vectors. This works because the broadcasting essentially copies the direction vector
        #   across the rows of the rotation matrix before the elementwise multiplication, and the sum is across the
        #   columns.
        rotations = c2w[:, :3, :3] # (num_rays, 3, 3)
        directions_stack = torch.sum(directions_stack[..., None, :] * rotations, dim=-1) # (3, num_rays, 3)
        directions_stack, _ = camera_utils.normalize_with_norm(directions_stack, -1)

        # Compute the approximate pixel area per ray
        dx = torch.sqrt(torch.sum((directions_stack[0] - directions_stack[1]) ** 2, dim=-1))  # (num_rays,)
        dy = torch.sqrt(torch.sum((directions_stack[0] - directions_stack[2]) ** 2, dim=-1))  # (num_rays,)
        pixel_area = dx * dy # (num_rays,)

        return RayBundle(
            origins=c2w[:, :3, 3],
            directions=directions_stack[0],
            pixel_area=pixel_area.unsqueeze(-1),
            camera_indices=camera_indices.unsqueeze(-1),
            metadata={},
        )
