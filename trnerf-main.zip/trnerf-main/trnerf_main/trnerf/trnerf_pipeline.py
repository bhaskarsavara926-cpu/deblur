"""
TRNeRF pipeline.
"""

import typing
from dataclasses import dataclass, field
from typing import Literal, Optional, Type
import torch.distributed as dist
from torch.cuda.amp.grad_scaler import GradScaler
from torch.nn.parallel import DistributedDataParallel as DDP

from nerfstudio.pipelines.base_pipeline import VanillaPipelineConfig, VanillaPipeline

from trnerf.trnerf_datamanager import TRNeRFDataManagerConfig, TRNeRFDataManager
from trnerf.trnerf_model import TRNeRFModel

@dataclass
class TRNeRFPipelineConfig(VanillaPipelineConfig):
    """TRNeRF pipeline config."""

    _target: Type = field(default_factory=lambda: TRNeRFPipeline)
    """Target class to instantiate"""

class TRNeRFPipeline(VanillaPipeline):
    """TRNeRF pipeline.

    This pipeline differs from the VanillaPipeline in only one significant way: it passes additional information to the
    TRNeRF model (the TRNeRFDataManagerConfig and the image dimensions). See the VanillaPipeline constructor for
    documentation of the constructor's arguments.
    """

    def __init__(
        self,
        config: TRNeRFPipelineConfig,
        device: str,
        test_mode: Literal["test", "val", "inference"] = "val",
        world_size: int = 1,
        local_rank: int = 0,
        grad_scaler: Optional[GradScaler] = None,
    ):
        super(VanillaPipeline, self).__init__()
        self.config = config
        self.test_mode = test_mode

        self.datamanager = config.datamanager.setup(
            device=device,
            test_mode=test_mode,
            world_size=world_size,
            local_rank=local_rank
        )
        self.datamanager.to(device)

        self._model = config.model.setup(
            scene_box=self.datamanager.train_dataset.scene_box,
            num_train_data=len(self.datamanager.train_dataset),
            metadata=self.datamanager.train_dataset.metadata,
            device=device,
            grad_scaler=grad_scaler,
            trnerf_datamanager_config=self.datamanager.config,
            height=int(self.datamanager.train_dataset.cameras.height[0, 0]),
            width=int(self.datamanager.train_dataset.cameras.width[0, 0]),
        )
        self.model.to(device)

        self.world_size = world_size
        if world_size > 1:
            self._model = typing.cast(TRNeRFModel, DDP(self._model, device_ids=[local_rank],
                find_unused_parameters=True))
            dist.barrier(device_ids=[local_rank])
