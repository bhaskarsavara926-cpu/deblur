"""
TRNeRF ray generator.
"""

from jaxtyping import Int
import torch

from nerfstudio.model_components.ray_generators import RayGenerator
from nerfstudio.cameras.cameras import Cameras
from nerfstudio.cameras.rays import RayBundle

from trnerf.trnerf_datamanager import TRNeRFDataManagerConfig
from trnerf.trnerf_cameras import TRNeRFCameraPoseInterpolator

class TRNeRFRayGenerator(RayGenerator):
    """TRNeRF ray generator.

    This ray generator optionally supports rolling shutter and motion blur correction by generating rays at interpolated
    camera poses and generating the multiple rays needed to render individual blurry pixels.

    Args:
        trnerf_datamanager_config: TRNeRF data manager config that determines how rays will be generated.
        cameras: Camera objects containing camera info.
    """

    def __init__(
        self,
        trnerf_datamanager_config: TRNeRFDataManagerConfig,
        cameras: Cameras,
    ):
        super().__init__(cameras)
        self.correct_blur = trnerf_datamanager_config.correct_blur
        self.correct_rolling_shutter = trnerf_datamanager_config.correct_rolling_shutter
        self.n_blur_samples = trnerf_datamanager_config.n_blur_samples
        self.duration_blur_samples = trnerf_datamanager_config.duration_blur_samples
        self.tau = trnerf_datamanager_config.tau
        self.readout_delay = trnerf_datamanager_config.readout_delay
        self.readout_row_duration = trnerf_datamanager_config.readout_row_duration

        # Initialize the pose interpolator if needed
        if self.correct_blur or self.correct_rolling_shutter:
            self.camera_pose_interpolator = TRNeRFCameraPoseInterpolator(cameras)

    def forward(self, ray_indices: Int[torch.Tensor, "num_rays 3"]) -> RayBundle:
        """Generate rays for target pixels.

        Args:
            ray_indices: Contains camera/image, row, and column indices for target pixels.
        """
        # Unpack the information for the target pixels
        c = ray_indices[:, 0]  # Camera/image indices
        y = ray_indices[:, 1]  # Row indices
        x = ray_indices[:, 2]  # Column indices

        # If correcting motion blur or rolling shutter, use custom methods to generate the rays
        if self.correct_blur or self.correct_rolling_shutter:
            # If correcting motion blur, generate n_blur_samples rays per pixel
            if self.correct_blur:
                n_initial = len(c)
                c = c.repeat(self.n_blur_samples)
                y = y.repeat(self.n_blur_samples)
                x = x.repeat(self.n_blur_samples)

            # If correcting rolling shutter, set the time offsets according to the delay between the trigger signal and
            # the time the pixel is read out
            if self.correct_rolling_shutter:
                readout_pixel_duration = self.readout_row_duration / int(self.cameras.width[0, 0])
                time_offsets = x * readout_pixel_duration + \
                    y * readout_pixel_duration * int(self.cameras.width[0, 0]) + self.readout_delay
            # Otherwise, initialize the time offsets to zero
            else:
                time_offsets = torch.zeros_like(x)
            time_offsets = time_offsets.to(torch.float64)

            # If correcting motion blur, adjust the time offsets of the n_blur_samples rays for each pixel such that the
            # rays are generated at evenly spaced points in time across the integration interval
            if self.correct_blur:
                time_blur_samples = torch.linspace(0, self.duration_blur_samples, self.n_blur_samples, device=c.device,
                    dtype=torch.float64)
                time_offsets -= time_blur_samples.repeat_interleave(n_initial)

            # Generate the rays
            coords = self.image_coords[y, x]
            ray_bundle = self.camera_pose_interpolator.generate_rays(c, coords, time_offsets)

        # If not correcting motion blur or rolling shutter, use the standard method for generating rays
        else:
            ray_bundle = super().forward(ray_indices)

        # Add the pixel coordinates that correspond to each ray (these are used later to look up the FPN offset).
        ray_bundle.metadata['x'] = x.unsqueeze(-1).to(ray_bundle.origins.device)
        ray_bundle.metadata['y'] = y.unsqueeze(-1).to(ray_bundle.origins.device)

        return ray_bundle
