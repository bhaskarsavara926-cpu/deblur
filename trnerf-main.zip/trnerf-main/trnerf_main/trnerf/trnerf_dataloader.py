"""
TRNeRF dataloader.
"""

from typing import Any, Callable, List, Optional, Union
import torch
import random
import multiprocessing
import concurrent.futures
from rich.progress import track

from nerfstudio.data.utils.dataloaders import CacheDataloader
from nerfstudio.data.utils.nerfstudio_collate import nerfstudio_collate
from nerfstudio.utils.rich_utils import CONSOLE

from trnerf.trnerf_datamanager import TRNeRFDataManagerConfig
from trnerf.trnerf_dataset import TRNeRFDataset

class TRNeRFDataloader(CacheDataloader):
    """TRNeRF dataloader.

    This dataloader is the same as the CacheDataloader, except it avoids sampling from images that would require pose
    extrapolation (rather than interpolation).

    Args:
        trnerf_datamanager_config: TRNeRF data manager config that determines which images can be sampled from.
        dataset: Dataset to sample from.
        num_samples_to_collate: How many images to sample rays for each batch. -1 for all images.
        num_times_to_repeat_images: How often to collate new images. -1 to never pick new images.
        device: Device to perform computation.
        collate_fn: The function we will use to collate our training data
    """

    def __init__(
        self,
        trnerf_datamanager_config: TRNeRFDataManagerConfig,
        dataset: TRNeRFDataset,
        num_images_to_sample_from: int = -1,
        num_times_to_repeat_images: int = -1,
        device: Union[torch.device, str] = "cpu",
        collate_fn: Callable[[Any], Any] = nerfstudio_collate,
        exclude_batch_keys_from_device: Optional[List[str]] = None,
        **kwargs,
    ):
        if exclude_batch_keys_from_device is None:
            exclude_batch_keys_from_device = ["image"]
        self.dataset = dataset

        super(CacheDataloader, self).__init__(dataset=dataset, **kwargs)
        self.num_times_to_repeat_images = num_times_to_repeat_images
        self.cache_all_images = (num_images_to_sample_from == -1) or (num_images_to_sample_from >= len(self.dataset))
        self.num_images_to_sample_from = len(self.dataset) if self.cache_all_images else num_images_to_sample_from

        # Determine the earliest and latest images that can be sampled from to avoid extrapolating poses
        if trnerf_datamanager_config.correct_blur or trnerf_datamanager_config.correct_rolling_shutter:
            assert not self.dataset.cameras.times is None
            timestamps = self.dataset.cameras.times[:, 0]
            readout_image_duration = trnerf_datamanager_config.readout_row_duration * \
                int(self.dataset.cameras.height[0, 0])

            # Determine the earliest image that can be used for training
            if trnerf_datamanager_config.correct_blur:
                for i in range(len(self.dataset)):
                    if trnerf_datamanager_config.correct_rolling_shutter:
                        timestamp_earliest = timestamps[i] + trnerf_datamanager_config.readout_delay - \
                            trnerf_datamanager_config.duration_blur_samples
                    else:
                        timestamp_earliest = timestamps[i] - trnerf_datamanager_config.duration_blur_samples

                    if timestamp_earliest >= torch.min(timestamps):
                        break
                assert i != len(self.dataset) - 1
                self.index_earliest = i
            else:
                self.index_earliest = 0

            # Determine the latest image that can be used for training
            if trnerf_datamanager_config.correct_rolling_shutter:
                for i in range(len(self.dataset) - 1, -1, -1):
                    timestamp_latest = timestamps[i] + trnerf_datamanager_config.readout_delay + readout_image_duration

                    if timestamp_latest <= torch.max(timestamps):
                        break
                assert i != 0
                self.index_latest = i
            else:
                self.index_latest = len(self.dataset) - 1

            max_num_images_to_sample_from = self.index_latest - self.index_earliest + 1
            assert max_num_images_to_sample_from > 0
            CONSOLE.print(f"Sampling images from {self.index_earliest} to {self.index_latest} to avoid extrapolation.")
            if self.num_images_to_sample_from > max_num_images_to_sample_from:
                self.num_images_to_sample_from = max_num_images_to_sample_from
        else:
            self.index_earliest = 0
            self.index_latest = len(self.dataset) - 1

        self.device = device
        self.collate_fn = collate_fn
        self.num_workers = kwargs.get("num_workers", 0)
        self.exclude_batch_keys_from_device = exclude_batch_keys_from_device

        self.num_repeated = self.num_times_to_repeat_images  # starting value
        self.first_time = True

        self.cached_collated_batch = None
        if self.cache_all_images:
            CONSOLE.print(f"Caching all {self.num_images_to_sample_from} images.")
            if self.num_images_to_sample_from > 500:
                CONSOLE.print(
                    "[bold yellow]Warning: If you run out of memory, try reducing the number of images to sample from."
                )
            self.cached_collated_batch = self._get_collated_batch()
        elif self.num_times_to_repeat_images == -1:
            CONSOLE.print(
                f"Caching {self.num_images_to_sample_from} out of {len(self.dataset)} images, without resampling."
            )
        else:
            CONSOLE.print(
                f"Caching {self.num_images_to_sample_from} out of {len(self.dataset)} images, "
                f"resampling every {self.num_times_to_repeat_images} iters."
            )

    def _get_batch_list(self):
        """This overrides the CacheDataloader version. The only difference is how the indices are sampled."""
        # Sampling between the earliest and latest indices that avoid extrapolating poses
        indices = random.sample(range(self.index_earliest, self.index_latest + 1), k=self.num_images_to_sample_from)

        batch_list = []
        results = []

        num_threads = int(self.num_workers) * 4
        num_threads = min(num_threads, multiprocessing.cpu_count() - 1)
        num_threads = max(num_threads, 1)

        with concurrent.futures.ThreadPoolExecutor(max_workers=num_threads) as executor:
            for idx in indices:
                res = executor.submit(self.dataset.__getitem__, idx)
                results.append(res)

            for res in track(results, description="Loading data batch", transient=True):
                batch_list.append(res.result())

        return batch_list
