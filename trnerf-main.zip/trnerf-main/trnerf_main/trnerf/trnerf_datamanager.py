"""
TRNeRF data manager.
"""

from dataclasses import dataclass, field
from typing import Type

from nerfstudio.data.datamanagers.base_datamanager import VanillaDataManager, VanillaDataManagerConfig
from nerfstudio.utils.rich_utils import CONSOLE

from trnerf.trnerf_dataset import TRNeRFDataset

@dataclass
class TRNeRFDataManagerConfig(VanillaDataManagerConfig):
    """TRNeRF data manager config."""

    _target: Type = field(default_factory=lambda: TRNeRFDataManager)
    """Target class to instantiate."""
    correct_blur: bool = True
    """Whether to correct motion blur."""
    correct_rolling_shutter: bool = True
    """Whether to correct rolling shutter."""
    n_blur_samples: int = 19
    """The number of rays to render for each pixel when correcting motion blur. Ignored if correct blur is False. This
    should be an odd number if Simpson's rule is being used to compute the integral."""
    duration_blur_samples: float = 40e-3
    """The duration over which to sample for blur correction (in seconds). Ignored if correct blur is False."""
    tau: float = 8e-3
    """The thermal time constant (in seconds)."""
    readout_delay: float = 0.5e-3
    """The delay between image capture being triggered and the beginning of readout (in seconds)."""
    readout_row_duration: float = 27.8e-6
    """The time it takes the camera to readout one row (in seconds)."""

class TRNeRFDataManager(VanillaDataManager[TRNeRFDataset]):
    """TRNeRF data manager.

    This data manager differs from the VanillaDataManager in only three ways:
    1. It supports additional arguments (through the TRNeRFDataManagerConfig).
    2. It uses a custom dataloader (TRNeRFDataloader) for training.
    3. It uses a custom ray generator (TRNeRFRayGenerator) for training.
    """

    def setup_train(self):
        """Sets up the data loaders for training"""

        from trnerf.trnerf_dataloader import TRNeRFDataloader
        from trnerf.trnerf_ray_generator import TRNeRFRayGenerator

        assert self.train_dataset is not None
        CONSOLE.print("Setting up training dataset...")
        self.train_image_dataloader = TRNeRFDataloader(
            self.config,
            self.train_dataset,
            num_images_to_sample_from=self.config.train_num_images_to_sample_from,
            num_times_to_repeat_images=self.config.train_num_times_to_repeat_images,
            device=self.device,
            num_workers=self.world_size * 4,
            pin_memory=True,
            collate_fn=self.config.collate_fn,
            exclude_batch_keys_from_device=self.exclude_batch_keys_from_device,
        )
        self.iter_train_image_dataloader = iter(self.train_image_dataloader)
        self.train_pixel_sampler = self._get_pixel_sampler(self.train_dataset, self.config.train_num_rays_per_batch)
        self.train_ray_generator = TRNeRFRayGenerator(self.config, self.train_dataset.cameras.to(self.device))
