"""
TRNeRF dataset.
"""

from typing import Dict
import numpy as np
import torch

from trnerf_utils import open_h5_image_file, read_image_at_timestamp

from nerfstudio.data.datasets.base_dataset import InputDataset
from nerfstudio.data.dataparsers.base_dataparser import DataparserOutputs

class TRNeRFDataset(InputDataset):
    """TRNeRF dataset.

    This dataset supports various ways to read in 16-bit thermal images. See the TRNeRFDataParserConfig for details
    regarding the options.

    Args:
        dataparser_outputs: Description of where and how to read input images.
        scale_factor: Unsupported argument.
    """

    def __init__(self, dataparser_outputs: DataparserOutputs, scale_factor: float = 1.0):
        assert scale_factor == 1.0, f"The TRNeRF dataset does not support rescaling images."
        super().__init__(dataparser_outputs, scale_factor)
        self.threshold_minimum = dataparser_outputs.metadata['threshold_minimum']
        self.threshold_maximum = dataparser_outputs.metadata['threshold_maximum']
        self.convert_to_8bit = dataparser_outputs.metadata['convert_to_8bit']
        self.gain = dataparser_outputs.metadata['gain']
        self.offset = dataparser_outputs.metadata['offset']

        # Open the H5 image file
        if len(dataparser_outputs.image_filenames) != 0:
            self.image_data_dict = open_h5_image_file(dataparser_outputs.image_filenames[0].parent)

    def get_data(self, image_idx: int) -> Dict:
        """Returns a dictionary with the image index and a three channel image as a float32 tensor in the range [0, 1].

        Args:
            image_idx: The image index in the dataset.
        """
        # Read in the image
        timestamp = int(self._dataparser_outputs.image_filenames[image_idx].parts[-1])
        image = read_image_at_timestamp(timestamp, self.image_data_dict, self.threshold_minimum, self.threshold_maximum,
            self.convert_to_8bit, self.gain, self.offset)
        if self.convert_to_8bit:
            image = image.astype(np.float32) / 255.0

        # Duplicate the image to create a three-channel image
        image = image[:, :, None].repeat(3, axis=2)

        # Output the image as a torch tensor
        image = torch.from_numpy(image)
        data = {"image_idx": image_idx, "image": image}

        return data
