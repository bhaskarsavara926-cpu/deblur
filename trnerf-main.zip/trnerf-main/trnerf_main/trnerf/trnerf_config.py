"""
TRNeRF configuration file.
"""

from nerfstudio.plugins.types import MethodSpecification
from nerfstudio.configs.base_config import ViewerConfig
from nerfstudio.engine.optimizers import AdamOptimizerConfig
from nerfstudio.engine.schedulers import ExponentialDecaySchedulerConfig
from nerfstudio.engine.trainer import TrainerConfig

from trnerf.trnerf_pipeline import TRNeRFPipelineConfig
from trnerf.trnerf_datamanager import TRNeRFDataManagerConfig
from trnerf.trnerf_dataparser import TRNeRFDataParserConfig
from trnerf.trnerf_model import TRNeRFModelConfig

trnerf_method = MethodSpecification(
    config=TrainerConfig(
        method_name="trnerf",
        steps_per_save=2000,
        max_num_iterations=60000,
        mixed_precision=True,
        pipeline=TRNeRFPipelineConfig(
            datamanager=TRNeRFDataManagerConfig(
                dataparser=TRNeRFDataParserConfig(),
                train_num_rays_per_batch=500,
            ),
            model=TRNeRFModelConfig(eval_num_rays_per_chunk=8192),
        ),
        optimizers={
            "fields": {
                "optimizer": AdamOptimizerConfig(lr=1e-2, eps=1e-15),
                "scheduler": ExponentialDecaySchedulerConfig(lr_final=0.0001, max_steps=200000),
            },
            "fpn_opt": {
                "optimizer": AdamOptimizerConfig(lr=1e-4, eps=1e-15),
                "scheduler": ExponentialDecaySchedulerConfig(lr_final=5e-5, max_steps=60000),
            },
        },
        viewer=ViewerConfig(num_rays_per_chunk=1 << 12),
        vis="viewer",
    ),
    description="Thermal Restoration NeRF (TRNeRF)",
)
