"""
TRNeRF data parser.
"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Type, Tuple
import numpy as np
import torch
from scipy.spatial.transform import Rotation
import h5py

from trnerf_utils import read_yaml, open_h5_pose_file, open_h5_image_file, to_transformations, \
    get_transformation_from_calib, invert_transformation_matrix

from nerfstudio.cameras.cameras import Cameras, CameraType
from nerfstudio.data.dataparsers.base_dataparser import DataParser, DataParserConfig, DataparserOutputs
from nerfstudio.data.scene_box import SceneBox

@dataclass
class TRNeRFDataParserConfig(DataParserConfig):
    """TRNeRF data parser config"""

    _target: Type = field(default_factory=lambda: TRNeRFDataParser)
    """Target class to instantiate"""
    data: Path = Path()
    """Unsupported argument inherited from the base DataParserConfig."""
    path_calibration_results: Path = Path()
    """Path to Kalibr camchain YAML file."""
    path_scaled_mono_left_poses: Path = Path()
    """Path to H5 file with scaled poses for the left monochrome camera."""
    path_images: Path = Path()
    """Path to H5 file with the thermal images to process."""
    path_two_point_nuc_results: Path = Path()
    """Optional path to H5 file with pixelwise offsets and gains estimated through a two-point NUC."""
    rotation: Tuple[float, float, float] = (0.0, 0.0, 0.0)
    """Rotation to apply to the poses. Specified as Euler angles (in degrees) that are applied as extrinsic rotations
     in xyz order about the axes of the nerfstudio viewer frame."""
    translation: Tuple[float, float, float] = (0.0, 0.0, 0.0)
    """Translation to apply to the poses. Specified in meters in the nerfstudio viewer frame. The poses are first
    centered around the mean position and then this translation is applied. This translation is applied before
    scaling."""
    scale_factor: float = 1.0
    """Scaling to apply to the poses."""
    threshold_minimum: float = 0.0
    """Minimum threshold used for remapping thermal image values."""
    threshold_maximum: float = 2**16 - 1
    """Maximum threshold used for remapping thermal image values."""
    threshold_minimum_viewer: float = 0.0
    """Minimum threshold used for remapping thermal image values to produce the viewer output."""
    threshold_maximum_viewer: float = 2**16 - 1
    """Maximum threshold used for remapping thermal image values to produce the viewer output."""
    convert_to_8bit: bool = False
    """Whether to convert the thermal images to 8-bit prior to mapping them to the range [0, 1] (note that this setting
    is not recommended and is only intended for testing the impact of converting thermal images to 8-bit, which is
    commonly see in available thermal datasets)."""

@dataclass
class TRNeRFDataParser(DataParser):
    """TRNeRF data parser

    This data parser reads directly from the TRNeRF dataset format.

    Args:
        config: The TRNeRFDataParserConfig used to instantiate class
    """

    config: TRNeRFDataParserConfig

    def _generate_dataparser_outputs(self, split="train"):
        assert self.config.data == Path(), 'The data argument inherited from the base DataParserConfig is unsupported.'
        assert self.config.path_calibration_results.exists(), \
            f"Calibration file {self.config.path_calibration_results} does not exist."
        assert self.config.path_scaled_mono_left_poses.exists(), \
            f"Scaled mono left poses file {self.config.path_scaled_mono_left_poses} does not exist."
        assert self.config.path_images.exists(), \
            f"Images file {self.config.path_images} does not exist."
        assert self.config.path_two_point_nuc_results.exists(), \
            f"Two point NUC results file {self.config.path_two_point_nuc_results} does not exist."

        # Read in calibration results
        calibration_results = read_yaml(self.config.path_calibration_results)

        # Read in pose data
        pose_data_dict = open_h5_pose_file(self.config.path_scaled_mono_left_poses)

        # Open H5 image file
        image_data_dict = open_h5_image_file(self.config.path_images)

        # Convert pose data to transformation matrices
        poses_world_to_mono_left = to_transformations(pose_data_dict['positions'],
            pose_data_dict['quaternions'])

        # Transform poses to the camera frame corresponding to the input images and invert
        transformation_mono_left_to_camera = get_transformation_from_calib(calibration_results, 'mono_left',
            image_data_dict['name'])
        poses_world_to_camera = transformation_mono_left_to_camera @ poses_world_to_mono_left
        poses_camera_to_world = np.asarray([invert_transformation_matrix(pose_world_to_camera)
            for pose_world_to_camera in poses_world_to_camera])

        # Convert from the current camera frame convention (x right, y down, z forward) to the OpenGL camera frame
        # convention (x right, y up, z back)
        # Equivalent to right multiplying the poses with transformation_cgl_to_camera (cgl = camera OpenGL):
        # [[1,  0,  0,  0],
        #  [0, -1,  0,  0],
        #  [0,  0, -1,  0],
        #  [0,  0,  0,  1]]
        poses_cgl_to_world = np.copy(poses_camera_to_world)
        poses_cgl_to_world[:, :, 1:3] *= -1

        # Transform the world frame from the COLMAP convention (x right, y down, z forward -- assuming the initial
        # camera pose is parallel to the ground) to the nerfstudio viewer convention (x right, y forward, z up)
        # Equivalent to left multiplying the poses with transformation_world_to_wv (wv = world viewer):
        # [[1,  0,  0,  0],
        #  [0,  0,  1,  0],
        #  [0, -1,  0,  0],
        #  [0,  0,  0,  1]]
        poses_cgl_to_wv = poses_cgl_to_world[:, np.array([0, 2, 1, 3]), :]
        poses_cgl_to_wv[:, 2, :] *= -1

        # Reorient and recenter the poses, i.e. transform them into a final world frame (wf = world final)
        transformation_wv_to_wf = np.eye(4)
        transformation_wv_to_wf[:3, :3] = \
            Rotation.from_euler('xyz', np.array(self.config.rotation), degrees=True).as_matrix()
        transformation_wv_to_wf[:3, 3] -= np.mean(poses_cgl_to_wv[:, :3, 3], axis=0)
        transformation_wv_to_wf[:3, 3] += np.array(self.config.translation)
        transformation_wv_to_wf = transformation_wv_to_wf[:3, :]
        poses_cgl_to_wf = transformation_wv_to_wf @ poses_cgl_to_wv

        # Compute the transformation from the COLMAP world frame to the final world frame
        transformation_world_to_wv = np.array([[1, 0, 0, 0], [0, 0, 1, 0], [0, -1, 0, 0], [0, 0, 0, 1]])
        transformation_world_to_wf = transformation_wv_to_wf @ transformation_world_to_wv
        transformation_world_to_wf = torch.from_numpy(transformation_world_to_wf)

        # Scale the poses
        poses_cgl_to_wf_scaled = np.copy(poses_cgl_to_wf)
        poses_cgl_to_wf_scaled[:, :3, 3] *= self.config.scale_factor
        poses_cgl_to_wf_scaled = torch.from_numpy(np.array(poses_cgl_to_wf_scaled).astype(np.float32))

        # Create the scene box with a side length of 2, centered about the origin of the final world frame
        scene_box = SceneBox(aabb=torch.tensor([[-1.0, -1.0, -1.0], [1.0, 1.0, 1.0]], dtype=torch.float32))

        # Set the camera intrinsic parameters
        # Add 0.5 to principal point due to differing conventions btw. Kalibr and COLMAP
        for key in calibration_results:
            if image_data_dict['name'] in calibration_results[key]['rostopic'].replace('/', '_'):
                calibration_result = calibration_results[key]
        camera_type = CameraType.PERSPECTIVE
        fx = float(calibration_result['intrinsics'][0])
        fy = float(calibration_result['intrinsics'][1])
        cx = float(calibration_result['intrinsics'][2]) + 0.5
        cy = float(calibration_result['intrinsics'][3]) + 0.5
        height = int(calibration_result['resolution'][1])
        width = int(calibration_result['resolution'][0])
        k1 = float(calibration_result['distortion_coeffs'][0])
        k2 = float(calibration_result['distortion_coeffs'][1])
        p1 = float(calibration_result['distortion_coeffs'][2])
        p2 = float(calibration_result['distortion_coeffs'][3])
        distortion_params = torch.Tensor([k1, k2, 0.0, 0.0, p1, p2])

        # Create the Cameras
        cameras = Cameras(fx=fx, fy=fy, cx=cx, cy=cy, distortion_params=distortion_params, height=height, width=width,
            camera_to_worlds=poses_cgl_to_wf_scaled[:, :3, :4], camera_type=camera_type, metadata={},
            times=torch.from_numpy(pose_data_dict['timestamps'] * 1e-9))

        # Set image_filenames (all images are used for training)
        # NOTE: these are not actual filenames, this is a hacky way to specify the images to read in from the H5 image
        # file. See the TRNeRFDataset for how this is used.
        if split == "train":
            image_filenames = [self.config.path_images / str(timestamp) for timestamp in pose_data_dict['timestamps']]
        else:
            image_filenames = []

        # Create the DataparserOutputs
        metadata = {
            'threshold_minimum': self.config.threshold_minimum,
            'threshold_maximum': self.config.threshold_maximum,
            'threshold_minimum_viewer': self.config.threshold_minimum_viewer,
            'threshold_maximum_viewer': self.config.threshold_maximum_viewer,
            'convert_to_8bit': self.config.convert_to_8bit}
        if self.config.path_two_point_nuc_results != Path():
            h5_file_two_point = h5py.File(self.config.path_two_point_nuc_results, 'r')
            metadata['gain'] = np.array(h5_file_two_point['gain'])
            metadata['offset'] = np.array(h5_file_two_point['offset'])
        else:
            metadata['gain'] = None
            metadata['offset'] = None
        dataparser_outputs = DataparserOutputs(
            image_filenames=image_filenames,
            cameras=cameras,
            scene_box=scene_box,
            mask_filenames=None,
            dataparser_scale=self.config.scale_factor,
            dataparser_transform=transformation_world_to_wf,
            metadata=metadata)

        return dataparser_outputs
